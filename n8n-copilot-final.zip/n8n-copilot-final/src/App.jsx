import { Routes, Route } from 'react-router-dom'
import { AuthProvider } from '@/contexts/AuthContext'
import Layout from '@/components/organisms/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import Home from '@/components/pages/Home'
import HowItWorks from '@/components/pages/HowItWorks'
import Features from '@/components/pages/Features'
import Pricing from '@/components/pages/Pricing'
import About from '@/components/pages/About'
import FAQ from '@/components/pages/FAQ'
import Login from '@/components/pages/Login'
import Signup from '@/components/pages/Signup'
import Dashboard from '@/components/pages/Dashboard'
import Profile from '@/components/pages/Profile'
import WorkflowBuilder from '@/components/pages/WorkflowBuilder'

function App() {
  return (
    <AuthProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/features" element={<Features />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/about" element={<About />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/builder" element={<WorkflowBuilder />} />
          <Route path="/workflows/new" element={
            <ProtectedRoute>
              <WorkflowBuilder />
            </ProtectedRoute>
          } />
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />
          <Route path="/profile" element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } />
        </Routes>
      </Layout>
    </AuthProvider>
  )
}

export default App