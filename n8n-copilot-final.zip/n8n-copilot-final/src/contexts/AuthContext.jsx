import { createContext, useContext, useReducer, useEffect } from 'react'
import { toast } from 'react-toastify'
import authService from '@/services/api/authService'

const AuthContext = createContext()

const authReducer = (state, action) => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload }
    case 'SET_USER':
      return { ...state, user: action.payload, loading: false }
    case 'SET_ERROR':
      return { ...state, error: action.payload, loading: false }
    case 'LOGOUT':
      return { ...state, user: null, loading: false }
    default:
      return state
  }
}

const initialState = {
  user: null,
  loading: true,
  error: null
}

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState)

  useEffect(() => {
    // Check for existing session on app load
    const checkAuth = async () => {
      try {
        const user = await authService.getCurrentUser()
        dispatch({ type: 'SET_USER', payload: user })
      } catch (error) {
        dispatch({ type: 'SET_USER', payload: null })
      }
    }

    checkAuth()
  }, [])

  const login = async (email, password) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true })
      const response = await authService.login(email, password)
      dispatch({ type: 'SET_USER', payload: response.user })
      toast.success('Successfully signed in!')
      return { success: true, user: response.user }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message })
      toast.error(error.message)
      return { success: false, error: error.message }
    }
  }

  const signup = async (userData) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true })
      const response = await authService.signup(userData)
      dispatch({ type: 'SET_USER', payload: response.user })
      toast.success('Account created successfully!')
      return { success: true, user: response.user }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message })
      toast.error(error.message)
      return { success: false, error: error.message }
    }
  }

  const logout = async () => {
    try {
      await authService.logout()
      dispatch({ type: 'LOGOUT' })
      toast.success('Successfully signed out!')
    } catch (error) {
      toast.error('Error signing out')
    }
  }

  const value = {
    user: state.user,
    loading: state.loading,
    error: state.error,
    login,
    signup,
    logout
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}