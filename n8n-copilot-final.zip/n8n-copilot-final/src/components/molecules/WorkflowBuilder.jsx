import { useState } from 'react'
import { motion } from 'framer-motion'
import { toast } from 'react-toastify'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import Textarea from '@/components/atoms/Textarea'
import ApperIcon from '@/components/ApperIcon'

const WorkflowBuilder = ({ onGenerate }) => {
  const [description, setDescription] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  
const validateDescription = (desc) => {
    const wordCount = desc.trim().split(/\s+/).length
    const hasAction = /\b(send|create|update|delete|notify|process|transform|filter|save|get|fetch)\b/i.test(desc)
    const hasTrigger = /\b(when|if|after|before|on|trigger|webhook|form|email|schedule)\b/i.test(desc)
    
    return {
      isValid: wordCount >= 10 && hasAction && hasTrigger,
      suggestions: [
        ...(wordCount < 10 ? ['Add more detail (at least 10 words)'] : []),
        ...(!hasAction ? ['Specify what action should happen'] : []),
        ...(!hasTrigger ? ['Describe what triggers the workflow'] : [])
      ]
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!description.trim()) {
      toast.error('Please describe your workflow')
      return
    }

    const validation = validateDescription(description)
    if (!validation.isValid) {
      toast.error(`Please improve description: ${validation.suggestions[0]}`)
      return
    }
    
    setIsGenerating(true)
    
    try {
      // Use the enhanced workflow service for generation
      const workflowService = (await import('@/services/api/workflowService')).default
      const generatedWorkflow = await workflowService.generateWorkflow(description)
      
      onGenerate(generatedWorkflow)
      toast.success('High-accuracy workflow generated successfully!')
      setDescription('')
      
    } catch (error) {
      toast.error('Failed to generate workflow - please try again')
      console.error('Generation error:', error)
    } finally {
      setIsGenerating(false)
    }
  }
  
  return (
    <Card glass className="max-w-2xl mx-auto">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-white mb-2">
          Describe Your Workflow
        </h3>
        <p className="text-slate-400">
          Tell us what you want to automate in plain English
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Example: When someone fills out my contact form, send them a welcome email and add them to my CRM..."
          rows={6}
          className="text-base"
        />
        
        <div className="flex items-center gap-4">
          <Button
            type="submit"
            loading={isGenerating}
            disabled={!description.trim()}
            size="lg"
            className="flex-1"
          >
            {isGenerating ? 'Generating...' : 'Generate Workflow'}
          </Button>
          
          <Button
            type="button"
            variant="ghost"
            onClick={() => setDescription('')}
            disabled={!description.trim()}
          >
            Clear
          </Button>
        </div>
      </form>
      
<div className="mt-6 p-4 bg-surface/50 rounded-lg border border-slate-700">
        <div className="flex items-start gap-3">
          <ApperIcon name="Lightbulb" className="text-accent flex-shrink-0 mt-0.5" size={16} />
          <div className="text-sm text-slate-300">
            <p className="font-medium mb-1">Tips for precise n8n workflows:</p>
            <ul className="space-y-1 text-slate-400">
              <li>• Start with a clear trigger (webhook, form submission, schedule)</li>
              <li>• Specify exact services to connect (Gmail, Slack, Airtable, etc.)</li>
              <li>• Include data transformation requirements</li>
              <li>• Mention error handling and retry logic if needed</li>
              <li>• Describe output format and destination</li>
            </ul>
          </div>
        </div>
      </div>
      
      {description.trim() && (() => {
        const validation = validateDescription(description)
        return !validation.isValid && (
          <div className="mt-4 p-3 bg-warning/10 rounded-lg border border-warning/20">
            <div className="flex items-start gap-2">
              <ApperIcon name="AlertTriangle" className="text-warning flex-shrink-0 mt-0.5" size={14} />
              <div className="text-sm">
                <p className="text-warning font-medium mb-1">Suggestions for better accuracy:</p>
                <ul className="space-y-1 text-warning/80">
                  {validation.suggestions.map((suggestion, index) => (
                    <li key={index}>• {suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )
      })()}
    </Card>
  )
}

export default WorkflowBuilder