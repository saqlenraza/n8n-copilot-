import { motion } from 'framer-motion'
import Card from '@/components/atoms/Card'
import ApperIcon from '@/components/ApperIcon'

const FeatureCard = ({ title, description, icon, gradient = false }) => {
  return (
    <Card hover glass className="group">
      <div className="flex flex-col items-center text-center space-y-4">
        <div className={`
          w-16 h-16 rounded-2xl flex items-center justify-center
          ${gradient 
            ? 'bg-gradient-to-br from-primary to-secondary' 
            : 'bg-surface border border-slate-600'
          }
          group-hover:scale-110 transition-transform duration-300
        `}>
          <ApperIcon 
            name={icon} 
            className={gradient ? 'text-white' : 'text-primary'} 
            size={24} 
          />
        </div>
        
        <div className="space-y-2">
          <h3 className="text-xl font-semibold text-white group-hover:text-primary transition-colors">
            {title}
          </h3>
          <p className="text-slate-400 leading-relaxed">
            {description}
          </p>
        </div>
      </div>
    </Card>
  )
}

export default FeatureCard