import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '@/contexts/AuthContext'
import Button from '@/components/atoms/Button'
import Input from '@/components/atoms/Input'
import ApperIcon from '@/components/ApperIcon'

const AuthModal = ({ isOpen, onClose, mode, onModeChange }) => {
  const { login, signup, loading } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch
  } = useForm()

  const password = watch('password')

  useEffect(() => {
    if (isOpen) {
      reset()
      setShowPassword(false)
    }
  }, [isOpen, mode, reset])

  const onSubmit = async (data) => {
    try {
      let result
      if (mode === 'login') {
        result = await login(data.email, data.password)
      } else {
        result = await signup(data)
      }
      
      if (result.success) {
        onClose()
        reset()
      }
    } catch (error) {
      // Error handling is done in AuthContext
    }
  }

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={handleBackdropClick}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="relative w-full max-w-md mx-auto glass-card rounded-2xl p-8 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-700/50"
            >
              <ApperIcon name="X" size={20} />
            </button>

            {/* Header */}
            <div className="text-center mb-8">
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center">
                  <ApperIcon name="Sparkles" className="text-white" size={24} />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">
                  {mode === 'login' ? 'Welcome back!' : 'Get started free'}
                </h2>
                <p className="text-slate-400">
                  {mode === 'login' 
                    ? 'Sign in to continue building workflows' 
                    : 'Create your account and start automating'
                  }
                </p>
              </motion.div>
            </div>

            {/* Form */}
            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              onSubmit={handleSubmit(onSubmit)}
              className="space-y-6"
            >
              {mode === 'signup' && (
                <Input
                  label="Full Name"
                  icon="User"
                  placeholder="Enter your full name"
                  {...register('name', {
                    required: 'Name is required',
                    minLength: {
                      value: 2,
                      message: 'Name must be at least 2 characters'
                    }
                  })}
                  error={errors.name?.message}
                />
              )}

              <Input
                label="Email Address"
                type="email"
                icon="Mail"
                placeholder="Enter your email"
                {...register('email', {
                  required: 'Email is required',
                  pattern: {
                    value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    message: 'Please enter a valid email address'
                  }
                })}
                error={errors.email?.message}
              />

              <div className="relative">
                <Input
                  label="Password"
                  type={showPassword ? 'text' : 'password'}
                  icon="Lock"
                  placeholder={mode === 'login' ? 'Enter your password' : 'Create a password'}
                  {...register('password', {
                    required: 'Password is required',
                    ...(mode === 'signup' && {
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters'
                      }
                    })
                  })}
                  error={errors.password?.message}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-9 text-slate-400 hover:text-white transition-colors"
                >
                  <ApperIcon name={showPassword ? 'EyeOff' : 'Eye'} size={18} />
                </button>
              </div>

              {mode === 'signup' && (
                <Input
                  label="Confirm Password"
                  type={showPassword ? 'text' : 'password'}
                  icon="Lock"
                  placeholder="Confirm your password"
                  {...register('confirmPassword', {
                    required: 'Please confirm your password',
                    validate: value => value === password || 'Passwords do not match'
                  })}
                  error={errors.confirmPassword?.message}
                />
              )}

              <Button
                type="submit"
                size="lg"
                className="w-full"
                loading={loading}
                icon={mode === 'login' ? 'LogIn' : 'UserPlus'}
              >
                {mode === 'login' ? 'Sign In' : 'Create Account'}
              </Button>
            </motion.form>

            {/* Footer */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="mt-8 text-center"
            >
              <p className="text-slate-400">
                {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
                <button
                  type="button"
                  onClick={() => onModeChange(mode === 'login' ? 'signup' : 'login')}
                  className="text-primary hover:text-secondary transition-colors font-medium"
                >
                  {mode === 'login' ? 'Sign up' : 'Sign in'}
                </button>
              </p>
            </motion.div>

            {/* Features for signup */}
            {mode === 'signup' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mt-6 pt-6 border-t border-slate-700"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-slate-300">
                    <ApperIcon name="Check" className="text-success" size={16} />
                    <span>Free forever plan</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-300">
                    <ApperIcon name="Check" className="text-success" size={16} />
                    <span>AI-powered workflow generation</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-300">
                    <ApperIcon name="Check" className="text-success" size={16} />
                    <span>Export to n8n JSON format</span>
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default AuthModal