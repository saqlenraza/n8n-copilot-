import { motion } from 'framer-motion'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import Badge from '@/components/atoms/Badge'
import ApperIcon from '@/components/ApperIcon'

const PricingCard = ({ 
  name, 
  price, 
  period = 'month',
  features, 
  highlighted = false,
  buttonText = 'Get Started',
  buttonVariant = 'primary'
}) => {
  return (
    <Card 
      className={`
        relative h-full
        ${highlighted 
          ? 'ring-2 ring-primary shadow-xl shadow-primary/20 scale-105' 
          : ''
        }
      `}
      glass
    >
      {highlighted && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <Badge variant="primary" size="md">
            <ApperIcon name="Star" size={14} />
            Most Popular
          </Badge>
        </div>
      )}
      
      <div className="text-center space-y-6">
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-white">{name}</h3>
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-4xl font-bold gradient-text">
              ${price}
            </span>
            {price > 0 && (
              <span className="text-slate-400">/{period}</span>
            )}
          </div>
        </div>
        
        <ul className="space-y-3 text-left">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-3">
              <ApperIcon 
                name="Check" 
                className="text-success flex-shrink-0 mt-0.5" 
                size={16} 
              />
              <span className="text-slate-300">{feature}</span>
            </li>
          ))}
        </ul>
        
        <Button 
          variant={highlighted ? 'primary' : 'outline'}
          size="lg"
          className="w-full"
        >
          {buttonText}
        </Button>
      </div>
    </Card>
  )
}

export default PricingCard