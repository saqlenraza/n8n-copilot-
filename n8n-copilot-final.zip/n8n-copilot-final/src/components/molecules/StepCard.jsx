import { motion } from 'framer-motion'
import Card from '@/components/atoms/Card'
import ApperIcon from '@/components/ApperIcon'

const StepCard = ({ number, title, description, icon, isActive = false }) => {
  return (
    <Card 
      glass 
      className={`
        workflow-step relative transition-all duration-300
        ${isActive ? 'ring-2 ring-primary shadow-lg shadow-primary/20' : ''}
      `}
    >
      <div className="flex items-start space-x-4">
        <div className={`
          w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0
          ${isActive 
            ? 'bg-gradient-to-br from-primary to-secondary text-white' 
            : 'bg-surface border border-slate-600 text-slate-400'
          }
        `}>
          <span className="text-lg font-bold">{number}</span>
        </div>
        
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <ApperIcon 
              name={icon} 
              className={isActive ? 'text-primary' : 'text-slate-400'} 
              size={20} 
            />
            <h3 className={`text-lg font-semibold ${isActive ? 'text-white' : 'text-slate-300'}`}>
              {title}
            </h3>
          </div>
          <p className="text-slate-400 leading-relaxed">
            {description}
          </p>
        </div>
      </div>
    </Card>
  )
}

export default StepCard