import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { toast } from 'react-toastify'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import ApperIcon from '@/components/ApperIcon'

const WorkflowViewer = ({ workflow }) => {
  const [activeTab, setActiveTab] = useState('steps')
  const [mermaidLoaded, setMermaidLoaded] = useState(false)
  
  useEffect(() => {
    if (activeTab === 'diagram') {
      import('mermaid').then((mermaid) => {
        mermaid.default.initialize({
          theme: 'dark',
          themeVariables: {
            primaryColor: '#6366f1',
            primaryTextColor: '#e2e8f0',
            primaryBorderColor: '#6366f1',
            lineColor: '#6366f1',
            secondaryColor: '#1e293b',
            tertiaryColor: '#334155'
          }
})
        
        setTimeout(() => {
          const diagramElement = document.getElementById('mermaid-diagram')
          if (diagramElement) {
            diagramElement.innerHTML = workflow.diagram
            mermaid.default.init(undefined, diagramElement)
              .then(() => setMermaidLoaded(true))
              .catch(console.error)
          }
        }, 100)
      })
    }
  }, [activeTab, workflow.diagram])
  
  const handleExport = () => {
    const dataStr = JSON.stringify(workflow.json, null, 2)
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr)
    
    const exportFileDefaultName = `${workflow.name.replace(/\s+/g, '-').toLowerCase()}.json`
    
    const linkElement = document.createElement('a')
    linkElement.setAttribute('href', dataUri)
    linkElement.setAttribute('download', exportFileDefaultName)
    linkElement.click()
    
    toast.success('Workflow exported successfully!')
  }
  
  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(workflow.json, null, 2))
    toast.success('JSON copied to clipboard!')
  }
  
  const tabs = [
    { id: 'steps', label: 'Steps', icon: 'List' },
    { id: 'diagram', label: 'Diagram', icon: 'GitBranch' },
    { id: 'json', label: 'JSON', icon: 'Code' }
  ]
  
  return (
    <Card glass className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-2xl font-bold text-white mb-1">
            {workflow.name}
</h3>
          <p className="text-slate-400">
            Generated workflow for n8n
          </p>
        </div>
        
        <div className="flex gap-2">
<Button
            variant="outline"
            size="sm"
            icon="Download"
            onClick={handleExport}
          >
            Export
          </Button>
        </div>
      </div>
      
      <div className="border-b border-slate-700 mb-6">
        <nav className="flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex items-center gap-2 py-3 px-1 border-b-2 font-medium text-sm transition-colors
                ${activeTab === tab.id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
                }
              `}
            >
              <ApperIcon name={tab.icon} size={16} />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      
      <div className="min-h-[400px]">
        {activeTab === 'steps' && (
          <div className="space-y-4">
            {workflow.steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-4 p-4 bg-surface/50 rounded-lg"
              >
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold">
                  {index + 1}
                </div>
                <span className="text-slate-200">{step}</span>
              </motion.div>
            ))}
          </div>
        )}
        
        {activeTab === 'diagram' && (
          <div className="bg-surface/30 rounded-lg p-6 text-center">
            <div id="mermaid-diagram" className="mermaid">
              {workflow.diagram}
            </div>
            {!mermaidLoaded && (
              <div className="flex items-center justify-center py-20">
                <div className="text-slate-400">Loading diagram...</div>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'json' && (
          <div className="space-y-4">
            <div className="flex justify-end">
              <Button
                variant="ghost"
                size="sm"
                icon="Copy"
                onClick={handleCopyJSON}
              >
                Copy JSON
              </Button>
            </div>
            <div className="bg-background rounded-lg p-4 border border-slate-700">
              <pre className="text-sm text-slate-300 overflow-x-auto">
                {JSON.stringify(workflow.json, null, 2)}
              </pre>
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}

export default WorkflowViewer