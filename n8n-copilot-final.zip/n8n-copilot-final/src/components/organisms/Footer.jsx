import { Link } from 'react-router-dom'
import ApperIcon from '@/components/ApperIcon'

const Footer = () => {
  const footerLinks = {
    product: [
      { name: 'Features', href: '/features' },
      { name: 'Pricing', href: '/pricing' },
      { name: 'How It Works', href: '/how-it-works' },
      { name: 'FAQ', href: '/faq' }
    ],
company: [
      { name: 'About', href: '/about' },
      { name: 'Blog', href: 'https://blog.n8ncopilot.com' },
      { name: 'Careers', href: 'https://jobs.n8ncopilot.com' },
      { name: 'Contact', href: 'mailto:hello@n8ncopilot.com' }
    ],
    resources: [
      { name: 'Documentation', href: 'https://docs.n8ncopilot.com' },
      { name: 'API Reference', href: 'https://api.n8ncopilot.com/docs' },
      { name: 'GitHub', href: 'https://github.com/n8n-copilot' },
      { name: 'Community', href: 'https://discord.gg/n8ncopilot' }
    ],
    legal: [
      { name: 'Privacy Policy', href: 'https://n8ncopilot.com/privacy' },
      { name: 'Terms of Service', href: 'https://n8ncopilot.com/terms' },
      { name: 'Cookie Policy', href: 'https://n8ncopilot.com/cookies' },
      { name: 'GDPR', href: 'https://n8ncopilot.com/gdpr' }
    ]
  }
  
  const socialLinks = [
    { name: 'Twitter', icon: 'Twitter', href: 'https://twitter.com/n8ncopilot' },
    { name: 'GitHub', icon: 'Github', href: 'https://github.com/n8n-copilot' },
    { name: 'LinkedIn', icon: 'Linkedin', href: 'https://linkedin.com/company/n8ncopilot' },
    { name: 'Discord', icon: 'MessageCircle', href: 'https://discord.gg/n8ncopilot' }
  ]
  
  return (
    <footer className="bg-surface/50 border-t border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                <ApperIcon name="Bot" className="text-white" size={20} />
              </div>
              <span className="text-xl font-bold text-white">n8n Copilot</span>
            </div>
            <p className="text-slate-400 mb-6 max-w-md">
              Transform your workflow descriptions into production-ready n8n automations with AI-powered generation.
            </p>
            <div className="flex gap-4">
{socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg bg-surface hover:bg-primary/20 text-slate-400 hover:text-primary transition-colors"
                >
                  <ApperIcon name={social.icon} size={18} />
                </a>
              ))}
            </div>
          </div>
          
          {/* Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Product</h3>
            <ul className="space-y-2">
              {footerLinks.product.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
{footerLinks.company.map((link) => (
                <li key={link.name}>
                  {link.href.startsWith('/') ? (
                    <Link
                      to={link.href}
                      className="text-slate-400 hover:text-white transition-colors"
                    >
                      {link.name}
                    </Link>
                  ) : (
                    <a
                      href={link.href}
                      target={link.href.startsWith('mailto:') ? '_self' : '_blank'}
                      rel={link.href.startsWith('mailto:') ? '' : 'noopener noreferrer'}
                      className="text-slate-400 hover:text-white transition-colors"
                    >
                      {link.name}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
{footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
{footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-400 text-sm">
            © 2024 n8n Copilot. All rights reserved.
          </p>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <span className="text-slate-400 text-sm">Made with</span>
            <ApperIcon name="Heart" className="text-red-500" size={16} />
            <span className="text-slate-400 text-sm">for the automation community</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer