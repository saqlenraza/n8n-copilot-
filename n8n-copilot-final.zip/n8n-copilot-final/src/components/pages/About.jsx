import { motion } from 'framer-motion'
import Card from '@/components/atoms/Card'
import Badge from '@/components/atoms/Badge'
import Button from '@/components/atoms/Button'
import ApperIcon from '@/components/ApperIcon'

const About = () => {
  const values = [
    {
      icon: 'Shield',
      title: 'Data Control',
      description: 'Your automation logic and data remain completely under your control with self-hosting options.'
    },
    {
      icon: 'Lock',
      title: 'Privacy First',
      description: 'We never store your workflow data. Everything processes locally or in your chosen environment.'
    },
    {
      icon: 'Users',
      title: 'Developer Friendly',
      description: 'Built by developers, for developers. We understand the importance of flexibility and control.'
    },
    {
      icon: 'Zap',
      title: 'Performance',
      description: 'Optimized for speed and reliability. Generate workflows in seconds, not minutes.'
    }
  ]
  
  const benefits = [
    {
      title: 'GDPR Compliance',
      description: 'Full compliance with European data protection regulations',
      icon: 'CheckCircle'
    },
    {
      title: 'HIPAA Ready',
      description: 'Healthcare-grade security and privacy controls',
      icon: 'Shield'
    },
    {
      title: 'SOC 2 Type II',
      description: 'Independently verified security and availability controls',
      icon: 'Award'
    },
    {
      title: 'On-Premise Option',
      description: 'Deploy entirely within your own infrastructure',
      icon: 'Server'
    }
  ]
  
  const team = [
    {
      name: 'Alex Johnson',
      role: 'CEO & Co-founder',
      description: 'Former automation engineer at scale-up companies, passionate about making complex workflows accessible.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face'
    },
    {
      name: 'Sarah Chen',
      role: 'CTO & Co-founder',
      description: 'AI researcher and former n8n contributor, leading our technical vision and product development.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&crop=face'
    },
    {
      name: 'Michael Rodriguez',
      role: 'Head of Engineering',
      description: 'Full-stack developer with expertise in automation platforms and developer tools.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face'
    }
  ]
  
  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="primary" size="md" className="mb-4">
            <ApperIcon name="Heart" size={14} />
            About n8n Copilot
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Empowering Automation for Everyone
          </h1>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            We believe powerful automation shouldn't require deep technical expertise. 
            n8n Copilot makes workflow creation accessible while maintaining the control and security that technical teams demand.
          </p>
        </motion.div>
        
        {/* Mission */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <Card glass className="max-w-4xl mx-auto text-center">
            <div className="space-y-6">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto">
                <ApperIcon name="Target" className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-white">
                Our Mission
              </h2>
              <p className="text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
                To democratize workflow automation by bridging the gap between natural language and technical implementation. 
                We're building the future where anyone can create sophisticated automations simply by describing what they want to achieve.
              </p>
            </div>
          </Card>
        </motion.div>
        
        {/* Why Self-Host */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Why Self-Hosting Matters
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              In an era of increasing data privacy concerns, self-hosting gives you complete control over your automation infrastructure.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass hover className="text-center h-full">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <ApperIcon name={value.icon} className="text-primary" size={24} />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {value.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {value.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Compliance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Enterprise-Grade Security & Compliance
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              Built with security and compliance in mind from day one. 
              Meet the strictest industry standards for data protection and privacy.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass hover>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-success/20 rounded-xl flex items-center justify-center flex-shrink-0">
                      <ApperIcon name={benefit.icon} className="text-success" size={24} />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {benefit.title}
                      </h3>
                      <p className="text-slate-400 leading-relaxed">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Developer DIY Ethos */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <Card glass className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl font-bold text-white mb-4">
                  Built for the Developer Community
                </h2>
                <p className="text-slate-300 mb-6 leading-relaxed">
                  We understand the developer mindset: you want tools that are powerful, 
                  flexible, and respect your intelligence. n8n Copilot is designed with the 
                  same philosophy that makes tools like n8n, Docker, and Kubernetes successful.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <ApperIcon name="Code" className="text-primary flex-shrink-0 mt-1" size={16} />
                    <span className="text-slate-400">Open architecture for extensibility</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ApperIcon name="GitBranch" className="text-primary flex-shrink-0 mt-1" size={16} />
                    <span className="text-slate-400">Version control and workflow management</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ApperIcon name="Terminal" className="text-primary flex-shrink-0 mt-1" size={16} />
                    <span className="text-slate-400">CLI tools and API-first approach</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ApperIcon name="Puzzle" className="text-primary flex-shrink-0 mt-1" size={16} />
                    <span className="text-slate-400">Modular design for custom integrations</span>
                  </li>
                </ul>
              </div>
              <div className="bg-surface/50 rounded-lg p-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <ApperIcon name="Coffee" className="text-white" size={32} />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    Made by Developers
                  </h3>
                  <p className="text-slate-400 text-sm">
                    "We built n8n Copilot because we were tired of spending hours on workflows that should take minutes. 
                    It's the tool we wished existed when we were building automations at scale."
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Team */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Meet the Team
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              A small but passionate team of automation enthusiasts, AI researchers, and developer advocates.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass hover className="text-center h-full">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-24 h-24 rounded-full mx-auto mb-4 border-2 border-primary/20"
                  />
                  <h3 className="text-xl font-semibold text-white mb-1">
                    {member.name}
                  </h3>
                  <p className="text-primary font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {member.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Community */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <Card glass className="max-w-4xl mx-auto text-center">
            <div className="space-y-6">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto">
                <ApperIcon name="Users" className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-white">
                Join Our Community
              </h2>
              <p className="text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
                Connect with other automation enthusiasts, share workflows, get help, and contribute to the future of AI-powered automation.
              </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  variant="outline" 
                  icon="Github"
                  onClick={() => window.open('https://github.com/n8n-copilot', '_blank')}
                >
                  GitHub
                </Button>
                <Button 
                  variant="outline" 
                  icon="MessageCircle"
                  onClick={() => window.open('https://discord.gg/n8ncopilot', '_blank')}
                >
                  Discord
                </Button>
                <Button 
                  variant="outline" 
                  icon="Twitter"
                  onClick={() => window.open('https://twitter.com/n8ncopilot', '_blank')}
                >
                  Twitter
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <Card glass className="max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              Ready to Transform Your Automation?
            </h3>
            <p className="text-slate-400 mb-6">
              Start building smarter workflows today. No technical expertise required, 
              but all the power and control you need.
            </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                icon="Rocket"
                onClick={() => window.open('https://app.n8ncopilot.com/signup', '_blank')}
              >
                Get Started Free
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                icon="MessageSquare"
                onClick={() => window.open('mailto:hello@n8ncopilot.com', '_self')}
              >
                Contact Us
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default About