import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAuth } from '@/contexts/AuthContext'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import ApperIcon from '@/components/ApperIcon'
import workflowService from '@/services/api/workflowService'

const Dashboard = () => {
  const { user } = useAuth()
  const [workflows, setWorkflows] = useState([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalWorkflows: 0,
    activeWorkflows: 0,
    totalExecutions: 0,
    successRate: 0
  })

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true)
        const workflowData = await workflowService.getAll()
        setWorkflows(workflowData.slice(0, 3)) // Show latest 3

        // Calculate stats
        const total = workflowData.length
        const active = workflowData.filter(w => w.status === 'active').length
        const executions = workflowData.reduce((sum, w) => sum + (w.executions || 0), 0)
        const successRate = workflowData.length > 0 
          ? Math.round((workflowData.filter(w => w.lastExecution?.status === 'success').length / total) * 100)
          : 0

        setStats({
          totalWorkflows: total,
          activeWorkflows: active,
          totalExecutions: executions,
          successRate
        })
      } catch (error) {
        console.error('Error loading dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }

    loadDashboardData()
  }, [])

  const statCards = [
    {
      title: 'Total Workflows',
      value: stats.totalWorkflows,
      icon: 'Workflow',
      color: 'text-primary',
      bg: 'bg-primary/10'
    },
    {
      title: 'Active Workflows',
      value: stats.activeWorkflows,
      icon: 'Play',
      color: 'text-success',
      bg: 'bg-success/10'
    },
    {
      title: 'Total Executions',
      value: stats.totalExecutions,
      icon: 'Activity',
      color: 'text-info',
      bg: 'bg-info/10'
    },
    {
      title: 'Success Rate',
      value: `${stats.successRate}%`,
      icon: 'TrendingUp',
      color: 'text-accent',
      bg: 'bg-accent/10'
    }
  ]

  const quickActions = [
    {
      title: 'Create Workflow',
      description: 'Start building a new automation',
      icon: 'Plus',
      href: '/workflows/new',
      color: 'primary'
    },
    {
      title: 'Browse Templates',
      description: 'Use pre-built workflow templates',
      icon: 'FileText',
      href: '/templates',
      color: 'secondary'
    },
    {
      title: 'View Analytics',
      description: 'Check your workflow performance',
      icon: 'BarChart3',
      href: '/analytics',
      color: 'accent'
    }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-2">
          Welcome back, {user?.name}! 👋
        </h1>
        <p className="text-slate-400">
          Here's what's happening with your workflows today.
        </p>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
      >
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 + index * 0.05 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm font-medium">{stat.title}</p>
                  <p className="text-2xl font-bold text-white mt-1">
                    {loading ? (
                      <div className="w-12 h-6 bg-slate-700 rounded animate-pulse" />
                    ) : (
                      stat.value
                    )}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-lg ${stat.bg} flex items-center justify-center`}>
                  <ApperIcon name={stat.icon} size={24} className={stat.color} />
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Workflows */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2"
        >
          <Card>
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-white">Recent Workflows</h2>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/workflows">View All</Link>
                </Button>
              </div>
            </div>
            <div className="p-6">
              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-700 rounded-lg animate-pulse" />
                      <div className="flex-1">
                        <div className="w-32 h-4 bg-slate-700 rounded animate-pulse mb-2" />
                        <div className="w-24 h-3 bg-slate-700 rounded animate-pulse" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : workflows.length > 0 ? (
                <div className="space-y-4">
                  {workflows.map((workflow) => (
                    <div key={workflow.Id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-surface/30 transition-colors">
                      <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                        <ApperIcon name="Workflow" size={20} className="text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-white">{workflow.name}</h3>
                        <p className="text-sm text-slate-400">
                          {workflow.description || 'No description'}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          workflow.status === 'active' ? 'bg-success' : 'bg-slate-500'
                        }`} />
                        <span className="text-sm text-slate-400 capitalize">
                          {workflow.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <ApperIcon name="Workflow" size={48} className="text-slate-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-white mb-2">No workflows yet</h3>
                  <p className="text-slate-400 mb-4">Create your first workflow to get started</p>
                  <Button asChild>
                    <Link to="/workflows/new">Create Workflow</Link>
                  </Button>
                </div>
              )}
            </div>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <div className="p-6 border-b border-slate-700">
              <h2 className="text-xl font-semibold text-white">Quick Actions</h2>
            </div>
            <div className="p-6">
              <div className="space-y-3">
                {quickActions.map((action, index) => (
                  <motion.div
                    key={action.title}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                  >
                    <Link
                      to={action.href}
                      className="flex items-center gap-3 p-3 rounded-lg border border-slate-700 hover:border-primary/50 hover:bg-surface/30 transition-all group"
                    >
                      <div className={`w-8 h-8 rounded-lg bg-${action.color}/20 flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <ApperIcon name={action.icon} size={16} className={`text-${action.color}`} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-white text-sm">{action.title}</h3>
                        <p className="text-xs text-slate-400">{action.description}</p>
                      </div>
                      <ApperIcon name="ChevronRight" size={16} className="text-slate-500 group-hover:text-primary transition-colors" />
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          </Card>

          {/* Recent Activity */}
          <Card className="mt-6">
            <div className="p-6 border-b border-slate-700">
              <h2 className="text-lg font-semibold text-white">Recent Activity</h2>
            </div>
            <div className="p-6">
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span className="text-slate-400">Workflow executed successfully</span>
                  <span className="text-slate-500 ml-auto">2h ago</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <span className="text-slate-400">New workflow created</span>
                  <span className="text-slate-500 ml-auto">5h ago</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-2 h-2 bg-warning rounded-full" />
                  <span className="text-slate-400">Workflow updated</span>
                  <span className="text-slate-500 ml-auto">1d ago</span>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default Dashboard