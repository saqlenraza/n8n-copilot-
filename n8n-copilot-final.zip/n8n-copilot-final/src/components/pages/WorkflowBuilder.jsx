import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '@/contexts/AuthContext'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import Textarea from '@/components/atoms/Textarea'
import Input from '@/components/atoms/Input'
import ApperIcon from '@/components/ApperIcon'
import WorkflowViewer from '@/components/molecules/WorkflowViewer'
import workflowService from '@/services/api/workflowService'

const WorkflowBuilder = () => {
  const { user } = useAuth()
  const [currentStep, setCurrentStep] = useState(1)
  const [workflowData, setWorkflowData] = useState({
    name: '',
    description: '',
    requirements: '',
    clarifications: [],
    generatedWorkflow: null
  })
  const [isGenerating, setIsGenerating] = useState(false)
  const [clarificationQuestions, setClarificationQuestions] = useState([])
  const [showPreview, setShowPreview] = useState(false)

  const steps = [
    {
      id: 1,
      title: 'Describe Your Workflow',
      description: 'Tell us what you want to automate',
      icon: 'MessageSquare'
    },
    {
      id: 2,
      title: 'Answer Clarifications',
      description: 'Help us understand your requirements',
      icon: 'HelpCircle'
    },
    {
      id: 3,
      title: 'Review & Generate',
      description: 'Review and generate your workflow',
      icon: 'Settings'
    },
    {
      id: 4,
      title: 'Export & Deploy',
      description: 'Get your n8n workflow JSON',
      icon: 'Download'
    }
  ]

  const examplePrompts = [
    {
      title: 'Email Automation',
      description: 'When someone fills out my contact form, send them a welcome email and add them to my CRM',
      icon: 'Mail'
    },
    {
      title: 'Social Media Monitoring',
      description: 'Monitor Twitter mentions of my brand and send notifications to Slack',
      icon: 'Twitter'
    },
    {
      title: 'Data Sync',
      description: 'Sync new customers from Stripe to my Google Sheets and send welcome emails',
      icon: 'Database'
    },
    {
      title: 'Content Publishing',
      description: 'When I publish a new blog post, automatically share it on all my social media platforms',
      icon: 'Share'
    }
  ]

  const handleDescriptionSubmit = async () => {
    if (!workflowData.description.trim()) return

    setIsGenerating(true)
    try {
      // Simulate AI clarification questions
      const questions = [
        'Which email service would you like to use? (Gmail, Outlook, SendGrid, etc.)',
        'What CRM system should we integrate with? (HubSpot, Salesforce, Pipedrive, etc.)',
        'Should we include any data validation for the form submissions?',
        'Do you want to set up any follow-up email sequences?'
      ]
      setClarificationQuestions(questions)
      setCurrentStep(2)
    } catch (error) {
      console.error('Error generating clarifications:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleClarificationComplete = async () => {
    setIsGenerating(true)
    try {
      const generatedWorkflow = await workflowService.generateWorkflow(workflowData.description)
      setWorkflowData(prev => ({ ...prev, generatedWorkflow }))
      setCurrentStep(4)
    } catch (error) {
      console.error('Error generating workflow:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleExampleSelect = (example) => {
    setWorkflowData(prev => ({
      ...prev,
      description: example.description
    }))
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">
                Describe Your Automation
              </h2>
              <p className="text-slate-400 text-lg">
                Tell us what you want to automate in plain English. Be as detailed as you like.
              </p>
            </div>

            <Card className="p-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Workflow Name (Optional)
                  </label>
                  <Input
                    value={workflowData.name}
                    onChange={(e) => setWorkflowData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Contact Form to CRM Integration"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Describe Your Workflow *
                  </label>
                  <Textarea
                    value={workflowData.description}
                    onChange={(e) => setWorkflowData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Example: When someone fills out my contact form, send them a welcome email and add them to my CRM with a follow-up task..."
                    rows={6}
                    className="w-full"
                  />
                </div>

                <div className="flex justify-between items-center pt-4">
                  <div className="text-sm text-slate-400">
                    {workflowData.description.length} characters
                  </div>
                  <Button
                    onClick={handleDescriptionSubmit}
                    disabled={!workflowData.description.trim() || isGenerating}
                    loading={isGenerating}
                    size="lg"
                    icon="ArrowRight"
                    iconPosition="right"
                  >
                    Continue
                  </Button>
                </div>
              </div>
            </Card>

            {/* Example Prompts */}
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-white mb-4">
                Or try one of these examples:
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {examplePrompts.map((example, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card 
                      hover 
                      className="p-4 cursor-pointer"
                      onClick={() => handleExampleSelect(example)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                          <ApperIcon name={example.icon} size={20} className="text-primary" />
                        </div>
                        <div>
                          <h4 className="font-medium text-white mb-1">{example.title}</h4>
                          <p className="text-sm text-slate-400">{example.description}</p>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )

      case 2:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">
                Answer a Few Questions
              </h2>
              <p className="text-slate-400 text-lg">
                Help us understand your specific requirements for better accuracy.
              </p>
            </div>

            <Card className="p-6">
              <div className="space-y-6">
                {clarificationQuestions.map((question, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="space-y-2"
                  >
                    <label className="block text-sm font-medium text-slate-300">
                      {index + 1}. {question}
                    </label>
                    <Input
                      placeholder="Your answer..."
                      className="w-full"
                    />
                  </motion.div>
                ))}

                <div className="flex justify-between items-center pt-6 border-t border-slate-700">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(1)}
                    icon="ArrowLeft"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleClarificationComplete}
                    loading={isGenerating}
                    size="lg"
                    icon="Sparkles"
                    iconPosition="right"
                  >
                    Generate Workflow
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )

      case 4:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">
                Your Workflow is Ready! 🎉
              </h2>
              <p className="text-slate-400 text-lg">
                Review your generated workflow and export it to n8n.
              </p>
            </div>

            {workflowData.generatedWorkflow && (
              <div className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-white">
                      {workflowData.generatedWorkflow.name}
                    </h3>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        icon="Eye"
                        onClick={() => setShowPreview(!showPreview)}
                      >
                        {showPreview ? 'Hide' : 'Preview'}
                      </Button>
                      <Button
                        size="sm"
                        icon="Download"
                        onClick={() => {
                          const blob = new Blob([JSON.stringify(workflowData.generatedWorkflow.json, null, 2)], {
                            type: 'application/json'
                          })
                          const url = URL.createObjectURL(blob)
                          const a = document.createElement('a')
                          a.href = url
                          a.download = `${workflowData.generatedWorkflow.name}.json`
                          a.click()
                        }}
                      >
                        Download JSON
                      </Button>
                    </div>
                  </div>
                  
                  <p className="text-slate-400 mb-4">
                    {workflowData.generatedWorkflow.description}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-surface/50 rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {workflowData.generatedWorkflow.nodeCount || 5}
                      </div>
                      <div className="text-sm text-slate-400">Nodes</div>
                    </div>
                    <div className="text-center p-4 bg-surface/50 rounded-lg">
                      <div className="text-2xl font-bold text-success">
                        {workflowData.generatedWorkflow.connections || 4}
                      </div>
                      <div className="text-sm text-slate-400">Connections</div>
                    </div>
                    <div className="text-center p-4 bg-surface/50 rounded-lg">
                      <div className="text-2xl font-bold text-accent">
                        Ready
                      </div>
                      <div className="text-sm text-slate-400">Status</div>
                    </div>
                  </div>
                </Card>

                <AnimatePresence>
                  {showPreview && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                    >
                      <WorkflowViewer workflow={workflowData.generatedWorkflow} />
                    </motion.div>
                  )}
                </AnimatePresence>

                <Card className="p-6 bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <ApperIcon name="Lightbulb" size={24} className="text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-2">Next Steps</h4>
                      <ul className="space-y-1 text-slate-300 text-sm">
                        <li>• Download the JSON file above</li>
                        <li>• Open your n8n instance</li>
                        <li>• Go to Workflows → Import from File</li>
                        <li>• Upload the downloaded JSON file</li>
                        <li>• Configure your credentials and test the workflow</li>
                      </ul>
                    </div>
                  </div>
                </Card>

                <div className="flex justify-center gap-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setCurrentStep(1)
                      setWorkflowData({
                        name: '',
                        description: '',
                        requirements: '',
                        clarifications: [],
                        generatedWorkflow: null
                      })
                      setClarificationQuestions([])
                    }}
                    icon="Plus"
                  >
                    Create Another
                  </Button>
                  <Button
                    onClick={() => window.open('https://n8n.io', '_blank')}
                    icon="ExternalLink"
                    iconPosition="right"
                  >
                    Open n8n
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-surface/20 to-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-white mb-4">
            AI Workflow Builder
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            Create production-ready n8n workflows with the power of AI. 
            Just describe what you want to automate, and we'll handle the rest.
          </p>
        </motion.div>

        {/* Progress Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-4 overflow-x-auto pb-4">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div className="flex flex-col items-center min-w-[200px]">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                        currentStep >= step.id
                          ? 'bg-primary text-white shadow-lg shadow-primary/25'
                          : 'bg-surface border-2 border-slate-600 text-slate-400'
                      }`}
                    >
                      <ApperIcon name={step.icon} size={20} />
                    </div>
                    <div className="text-center mt-2">
                      <div
                        className={`font-medium text-sm ${
                          currentStep >= step.id ? 'text-white' : 'text-slate-400'
                        }`}
                      >
                        {step.title}
                      </div>
                      <div className="text-xs text-slate-500">{step.description}</div>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div
                      className={`w-16 h-0.5 mx-4 transition-all duration-300 ${
                        currentStep > step.id ? 'bg-primary' : 'bg-slate-600'
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="max-w-4xl mx-auto"
        >
          {renderStepContent()}
        </motion.div>
      </div>
    </div>
  )
}

export default WorkflowBuilder

