import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { motion } from 'framer-motion'
import { toast } from 'react-toastify'
import { useAuth } from '@/contexts/AuthContext'
import authService from '@/services/api/authService'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import Input from '@/components/atoms/Input'
import ApperIcon from '@/components/ApperIcon'

const Profile = () => {
  const { user } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [isPasswordLoading, setIsPasswordLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('profile')

  const {
    register: registerProfile,
    handleSubmit: handleProfileSubmit,
    formState: { errors: profileErrors },
    reset: resetProfile,
    setError: setProfileError
  } = useForm()

  const {
    register: registerPassword,
    handleSubmit: handlePasswordSubmit,
    formState: { errors: passwordErrors },
    reset: resetPassword,
    setError: setPasswordError,
    watch
  } = useForm()

  const newPassword = watch('newPassword')

  useEffect(() => {
    if (user) {
      resetProfile({
        name: user.name,
        email: user.email
      })
    }
  }, [user, resetProfile])

  const onProfileSubmit = async (data) => {
    setIsLoading(true)
    
    try {
      await authService.updateProfile({
        name: data.name,
        email: data.email
      })
      
      toast.success('Profile updated successfully!')
    } catch (error) {
      setProfileError('root', { message: error.message })
      toast.error(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const onPasswordSubmit = async (data) => {
    setIsPasswordLoading(true)
    
    try {
      await authService.changePassword(data.currentPassword, data.newPassword)
      toast.success('Password changed successfully!')
      resetPassword()
    } catch (error) {
      setPasswordError('root', { message: error.message })
      toast.error(error.message)
    } finally {
      setIsPasswordLoading(false)
    }
  }

  const tabs = [
    { id: 'profile', name: 'Profile Information', icon: 'User' },
    { id: 'security', name: 'Security', icon: 'Shield' },
    { id: 'preferences', name: 'Preferences', icon: 'Settings' }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Profile Settings</h1>
          <p className="text-slate-400">Manage your account settings and preferences</p>
        </div>

        {/* User Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                <ApperIcon name="User" size={32} className="text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-white">{user?.name}</h2>
                <p className="text-slate-400">{user?.email}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span className="text-sm text-slate-400">Active</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-sm text-slate-400">Member since {new Date(user?.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Tab Navigation */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="p-4">
              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-primary text-white'
                        : 'text-slate-400 hover:text-white hover:bg-surface/50'
                    }`}
                  >
                    <ApperIcon name={tab.icon} size={16} />
                    <span className="text-sm font-medium">{tab.name}</span>
                  </button>
                ))}
              </nav>
            </Card>
          </motion.div>

          {/* Tab Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-3"
          >
            {/* Profile Information Tab */}
            {activeTab === 'profile' && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-white mb-6">Profile Information</h3>
                
                <form onSubmit={handleProfileSubmit(onProfileSubmit)} className="space-y-6">
                  {profileErrors.root && (
                    <div className="bg-error/10 border border-error/20 rounded-lg p-3">
                      <div className="flex items-center gap-2">
                        <ApperIcon name="AlertCircle" size={16} className="text-error" />
                        <span className="text-error text-sm">{profileErrors.root.message}</span>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Full Name
                    </label>
                    <Input
                      type="text"
                      placeholder="Enter your full name"
                      {...registerProfile('name', {
                        required: 'Name is required',
                        minLength: {
                          value: 2,
                          message: 'Name must be at least 2 characters'
                        }
                      })}
                      error={profileErrors.name?.message}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Email Address
                    </label>
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      {...registerProfile('email', {
                        required: 'Email is required',
                        pattern: {
                          value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                          message: 'Invalid email format'
                        }
                      })}
                      error={profileErrors.email?.message}
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                          Saving...
                        </div>
                      ) : (
                        'Save Changes'
                      )}
                    </Button>
                  </div>
                </form>
              </Card>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-white mb-6">Security Settings</h3>
                
                <form onSubmit={handlePasswordSubmit(onPasswordSubmit)} className="space-y-6">
                  {passwordErrors.root && (
                    <div className="bg-error/10 border border-error/20 rounded-lg p-3">
                      <div className="flex items-center gap-2">
                        <ApperIcon name="AlertCircle" size={16} className="text-error" />
                        <span className="text-error text-sm">{passwordErrors.root.message}</span>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Current Password
                    </label>
                    <Input
                      type="password"
                      placeholder="Enter current password"
                      {...registerPassword('currentPassword', {
                        required: 'Current password is required'
                      })}
                      error={passwordErrors.currentPassword?.message}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      New Password
                    </label>
                    <Input
                      type="password"
                      placeholder="Enter new password"
                      {...registerPassword('newPassword', {
                        required: 'New password is required',
                        minLength: {
                          value: 6,
                          message: 'Password must be at least 6 characters'
                        }
                      })}
                      error={passwordErrors.newPassword?.message}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Confirm New Password
                    </label>
                    <Input
                      type="password"
                      placeholder="Confirm new password"
                      {...registerPassword('confirmPassword', {
                        required: 'Please confirm your new password',
                        validate: value =>
                          value === newPassword || 'Passwords do not match'
                      })}
                      error={passwordErrors.confirmPassword?.message}
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isPasswordLoading}>
                      {isPasswordLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                          Changing...
                        </div>
                      ) : (
                        'Change Password'
                      )}
                    </Button>
                  </div>
                </form>
              </Card>
            )}

            {/* Preferences Tab */}
            {activeTab === 'preferences' && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-white mb-6">Preferences</h3>
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-medium">Email Notifications</h4>
                      <p className="text-sm text-slate-400">Receive email updates about your workflows</p>
                    </div>
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-primary bg-surface border-slate-600 rounded focus:ring-primary focus:ring-2"
                      defaultChecked={user?.preferences?.notifications}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-medium">Dark Theme</h4>
                      <p className="text-sm text-slate-400">Use dark theme for the interface</p>
                    </div>
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-primary bg-surface border-slate-600 rounded focus:ring-primary focus:ring-2"
                      defaultChecked={true}
                      disabled
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Language
                    </label>
                    <select className="w-full px-3 py-2 bg-surface border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-primary focus:border-transparent">
                      <option value="en">English</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                      <option value="de">German</option>
                    </select>
                  </div>

                  <div className="flex justify-end">
                    <Button onClick={() => toast.success('Preferences saved!')}>
                      Save Preferences
                    </Button>
                  </div>
                </div>
              </Card>
            )}
          </motion.div>
        </div>
      </motion.div>
    </div>
  )
}

export default Profile