import { useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import Button from '@/components/atoms/Button'
import Card from '@/components/atoms/Card'
import Badge from '@/components/atoms/Badge'
import FeatureCard from '@/components/molecules/FeatureCard'
import WorkflowBuilder from '@/components/molecules/WorkflowBuilder'
import WorkflowViewer from '@/components/molecules/WorkflowViewer'
import ApperIcon from '@/components/ApperIcon'
import AuthModal from '@/components/molecules/AuthModal'

const Home = () => {
  const [generatedWorkflow, setGeneratedWorkflow] = useState(null)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [authMode, setAuthMode] = useState('signup') // 'login' or 'signup'
  const { user } = useAuth()

  const handleGetStarted = () => {
    setAuthMode('signup')
    setShowAuthModal(true)
  }

  const stats = [
    { value: '10,000+', label: 'Workflows Generated', icon: 'Workflow' },
    { value: '99.9%', label: 'Uptime', icon: 'TrendingUp' },
    { value: '500+', label: 'Happy Users', icon: 'Users' },
    { value: '24/7', label: 'Support', icon: 'Clock' }
  ]
  
  const features = [
    {
      title: 'AI Clarification Engine',
      description: 'Our AI asks intelligent follow-up questions to understand your exact requirements.',
      icon: 'MessageSquare',
      gradient: true,
      color: 'from-blue-500 to-purple-600'
    },
    {
      title: 'Exportable JSON',
      description: 'Get production-ready n8n workflow JSON files that you can import directly.',
      icon: 'Download',
      gradient: true,
      color: 'from-green-500 to-teal-600'
    },
    {
      title: 'Visual Diagrams',
      description: 'See your workflow logic in beautiful Mermaid diagrams before deployment.',
      icon: 'GitBranch',
      gradient: true,
      color: 'from-orange-500 to-red-600'
    },
    {
      title: 'One-Click Deploy',
      description: 'Connect your n8n instance and deploy workflows with a single click.',
      icon: 'Zap',
      gradient: true
    }
  ]
  
  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Operations Manager',
      company: 'TechCorp',
      content: 'n8n Copilot saved us hours of workflow design time. The AI truly understands what we need.',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=64&h=64&fit=crop&crop=face'
    },
    {
      name: 'Michael Chen',
      role: 'Technical Lead',
      company: 'StartupXYZ',
      content: 'The JSON export feature is perfect. We can review and customize before deploying.',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face'
    },
    {
      name: 'Emily Rodriguez',
      role: 'No-Code Developer',
      company: 'Freelancer',
      content: 'This tool has revolutionized how I approach automation projects for my clients.',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face'
    }
  ]
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="hero-bg relative overflow-hidden py-20 sm:py-32">
        {/* Animated background elements */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-accent/10 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }} />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <Badge variant="primary" size="md" className="mb-6">
              <ApperIcon name="Sparkles" size={14} />
              AI-Powered Workflow Generation
            </Badge>
            
            <h1 className="text-4xl sm:text-6xl font-bold text-white mb-6">
              Turn Ideas Into{' '}
              <span className="gradient-text">n8n Workflows</span>
            </h1>
            
            <p className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto">
              Building complex workflows in n8n is hard. We make it trivial. 
              Describe your automation in plain English and get production-ready workflows instantly.
            </p>
            
<div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                size="xl" 
                icon="Rocket"
                onClick={handleGetStarted}
              >
                Get Started Free
              </Button>
              <Button 
                size="xl" 
                variant="outline" 
                icon="PlayCircle"
                onClick={() => window.open('https://demo.n8ncopilot.com', '_blank')}
              >
                Watch Demo
              </Button>
            </div>
            
            <div className="flex flex-wrap justify-center gap-8 text-center">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="min-w-[120px]"
                >
                  <div className="text-3xl font-bold gradient-text">{stat.value}</div>
                  <div className="text-sm text-slate-400">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Problem Statement */}
      <section className="py-20 bg-gradient-to-r from-surface/50 to-slate-800/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Building complex workflows shouldn't be complex
            </h2>
            <p className="text-xl text-slate-400 mb-8">
              n8n is powerful, but creating workflows from scratch takes time. 
              Our AI understands your requirements and generates complete, deployable workflows in minutes.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Badge variant="outline" size="md">
                <ApperIcon name="Server" size={14} />
                Self-Hosted
              </Badge>
              <Badge variant="outline" size="md">
                <ApperIcon name="Brain" size={14} />
                AI-Driven
              </Badge>
              <Badge variant="outline" size="md">
                <ApperIcon name="FileJson" size={14} />
                Exportable JSON
              </Badge>
              <Badge variant="outline" size="md">
                <ApperIcon name="Eye" size={14} />
                Visual Diagrams
              </Badge>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Features */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Everything you need to automate smarter
            </h2>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto">
              From natural language processing to production deployment, 
              we've got every step of your automation journey covered.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <FeatureCard {...feature} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
{/* Interactive Demo / Auth Gate */}
      <section className="py-20 bg-gradient-to-r from-primary/5 to-secondary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              {user ? 'Build Your Workflow' : 'Try it yourself'}
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              {user 
                ? 'Create and generate production-ready n8n workflows with AI assistance.'
                : 'Experience the power of AI-driven workflow generation. Sign up to get started.'
              }
            </p>
          </motion.div>
          
          {user ? (
            <div className="space-y-12">
              <WorkflowBuilder onGenerate={setGeneratedWorkflow} />
              
              {generatedWorkflow && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  <WorkflowViewer workflow={generatedWorkflow} />
                </motion.div>
              )}
            </div>
          ) : (
            <div className="max-w-4xl mx-auto">
              <Card glass className="text-center">
                <div className="py-12 px-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                    <ApperIcon name="Lock" size={32} className="text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Unlock AI-Powered Workflow Generation
                  </h3>
                  
                  <p className="text-lg text-slate-400 mb-8 max-w-2xl mx-auto">
                    Get instant access to our workflow builder and start creating production-ready n8n automations in minutes, not hours.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                        <ApperIcon name="Zap" size={20} className="text-primary" />
                      </div>
                      <h4 className="font-semibold text-white mb-2">Instant Generation</h4>
                      <p className="text-sm text-slate-400">AI creates complete workflows from your description</p>
                    </div>
                    
                    <div className="text-center">
                      <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                        <ApperIcon name="Download" size={20} className="text-secondary" />
                      </div>
                      <h4 className="font-semibold text-white mb-2">Export Ready</h4>
                      <p className="text-sm text-slate-400">Download JSON files for direct n8n import</p>
                    </div>
                    
                    <div className="text-center">
                      <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                        <ApperIcon name="GitBranch" size={20} className="text-accent" />
                      </div>
                      <h4 className="font-semibold text-white mb-2">Visual Diagrams</h4>
                      <p className="text-sm text-slate-400">See your workflow logic before deployment</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button 
                      size="xl" 
                      icon="Rocket"
                      onClick={handleGetStarted}
                    >
                      Start Building Free
                    </Button>
                    <Button 
                      size="xl" 
                      variant="outline" 
                      icon="PlayCircle"
                      onClick={() => window.open('https://demo.n8ncopilot.com', '_blank')}
                    >
                      Watch Demo
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          )}
        </div>
      </section>
      
      {/* Social Proof */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Trusted by automation experts
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              See what developers and operations teams are saying about n8n Copilot.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass className="h-full">
                  <div className="flex items-center gap-4 mb-4">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full"
                    />
                    <div>
                      <h4 className="font-semibold text-white">{testimonial.name}</h4>
                      <p className="text-sm text-slate-400">{testimonial.role} at {testimonial.company}</p>
                    </div>
                  </div>
                  <p className="text-slate-300 leading-relaxed">
                    "{testimonial.content}"
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Ready to automate smarter?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Join thousands of developers and operations teams who are already using n8n Copilot 
              to build better workflows faster.
            </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="xl" 
                variant="secondary" 
                icon="Rocket"
                onClick={handleGetStarted}
              >
                Start Free Trial
              </Button>
              <Button 
                size="xl" 
                variant="outline" 
                icon="Calendar"
                onClick={() => window.open('https://calendly.com/n8ncopilot/demo', '_blank')}
              >
                Schedule Demo
              </Button>
            </div>
          </motion.div>
        </div>
</section>
      
      {/* Authentication Modal */}
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
        onModeChange={setAuthMode}
      />
    </div>
  )
}

export default Home