import { useState } from 'react'
import { motion } from 'framer-motion'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import Badge from '@/components/atoms/Badge'
import PricingCard from '@/components/molecules/PricingCard'
import ApperIcon from '@/components/ApperIcon'

const Pricing = () => {
  const [billingPeriod, setBillingPeriod] = useState('monthly')
  
  const plans = [
    {
      name: 'Free',
      price: 0,
      period: billingPeriod,
      features: [
        'Unlimited text-based workflow planning',
        'AI clarification engine',
        'Basic workflow visualization',
        'Community support',
        'Up to 5 workflow generations per month'
      ],
      buttonText: 'Get Started Free',
      buttonVariant: 'outline'
    },
    {
      name: 'Pro',
      price: billingPeriod === 'monthly' ? 29 : 290,
      period: billingPeriod,
      features: [
        'Everything in Free',
        'Unlimited workflow generations',
        'JSON & diagram exports',
        'Custom branding',
        'Direct n8n API integration',
        'Priority support',
        'Advanced workflow templates'
      ],
      highlighted: true,
      buttonText: 'Start Pro Trial',
      buttonVariant: 'primary'
    },
    {
      name: 'Enterprise',
      price: billingPeriod === 'monthly' ? 99 : 990,
      period: billingPeriod,
      features: [
        'Everything in Pro',
        'SSO & SAML integration',
        'Comprehensive audit logs',
        'On-premise deployment',
        'Custom integrations',
        'Dedicated support manager',
        'SLA guarantees',
        'Advanced security controls'
      ],
      buttonText: 'Contact Sales',
      buttonVariant: 'outline'
    }
  ]
  
  const faqs = [
    {
      question: 'Can I switch plans anytime?',
      answer: 'Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.'
    },
    {
      question: 'Do you offer refunds?',
      answer: 'We offer a 30-day money-back guarantee for all paid plans. If you\'re not satisfied, we\'ll refund your payment.'
    },
    {
      question: 'What happens to my data if I cancel?',
      answer: 'Your data remains accessible for 30 days after cancellation. You can export all your workflows and data during this period.'
    },
    {
      question: 'Is there a setup fee?',
      answer: 'No setup fees for any plan. You only pay the monthly or annual subscription fee.'
    }
  ]
  
  const features = [
    {
      icon: 'Shield',
      title: 'Enterprise Security',
      description: 'SOC 2 compliance, encryption at rest and in transit'
    },
    {
      icon: 'Clock',
      title: '99.9% Uptime',
      description: 'Reliable service with SLA guarantees'
    },
    {
      icon: 'Users',
      title: 'Team Collaboration',
      description: 'Built for teams of all sizes'
    },
    {
      icon: 'Support',
      title: 'Expert Support',
      description: 'Get help from automation experts'
    }
  ]
  
  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="primary" size="md" className="mb-4">
            <ApperIcon name="DollarSign" size={14} />
            Simple, Transparent Pricing
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Choose Your Plan
          </h1>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto mb-8">
            Start free and scale as you grow. No hidden fees, no surprises. 
            All plans include our core AI-powered workflow generation.
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <span className={`text-sm ${billingPeriod === 'monthly' ? 'text-white' : 'text-slate-400'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingPeriod(billingPeriod === 'monthly' ? 'yearly' : 'monthly')}
              className={`
                relative w-14 h-8 rounded-full transition-colors
                ${billingPeriod === 'yearly' ? 'bg-primary' : 'bg-slate-600'}
              `}
            >
              <div className={`
                absolute w-6 h-6 bg-white rounded-full top-1 transition-transform
                ${billingPeriod === 'yearly' ? 'translate-x-7' : 'translate-x-1'}
              `} />
            </button>
            <span className={`text-sm ${billingPeriod === 'yearly' ? 'text-white' : 'text-slate-400'}`}>
              Yearly
            </span>
            {billingPeriod === 'yearly' && (
              <Badge variant="success" size="sm">
                Save 20%
              </Badge>
            )}
          </div>
        </motion.div>
        
        {/* Pricing Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20"
        >
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <PricingCard {...plan} />
            </motion.div>
          ))}
        </motion.div>
        
        {/* Feature Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Detailed Feature Comparison
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              See exactly what's included in each plan to choose the best fit for your needs.
            </p>
          </div>
          
          <Card glass className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-4 px-6 text-white font-semibold">Feature</th>
                  <th className="text-center py-4 px-6 text-white font-semibold">Free</th>
                  <th className="text-center py-4 px-6 text-white font-semibold">Pro</th>
                  <th className="text-center py-4 px-6 text-white font-semibold">Enterprise</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">Workflow Generations</td>
                  <td className="py-4 px-6 text-center text-slate-400">5/month</td>
                  <td className="py-4 px-6 text-center text-success">Unlimited</td>
                  <td className="py-4 px-6 text-center text-success">Unlimited</td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">AI Clarification</td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">JSON Export</td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">Visual Diagrams</td>
                  <td className="py-4 px-6 text-center text-slate-400">Basic</td>
                  <td className="py-4 px-6 text-center text-success">Advanced</td>
                  <td className="py-4 px-6 text-center text-success">Advanced</td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">n8n Integration</td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">Custom Branding</td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">SSO Integration</td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                </tr>
                <tr className="border-b border-slate-700/50">
                  <td className="py-4 px-6 text-slate-300">Audit Logs</td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="X" className="text-slate-500 mx-auto" size={16} /></td>
                  <td className="py-4 px-6 text-center"><ApperIcon name="Check" className="text-success mx-auto" size={16} /></td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-slate-300">Support</td>
                  <td className="py-4 px-6 text-center text-slate-400">Community</td>
                  <td className="py-4 px-6 text-center text-success">Priority</td>
                  <td className="py-4 px-6 text-center text-success">Dedicated</td>
                </tr>
              </tbody>
            </table>
          </Card>
        </motion.div>
        
        {/* Why Choose Us */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Why Teams Choose n8n Copilot
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              More than just pricing - we deliver value that scales with your business.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass hover className="text-center h-full">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <ApperIcon name={feature.icon} className="text-primary" size={24} />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-slate-400 text-sm">
                    {feature.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* FAQ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              Common questions about our pricing and plans.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {faq.question}
                  </h3>
                  <p className="text-slate-400">
                    {faq.answer}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <Card glass className="max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              Ready to Get Started?
            </h3>
            <p className="text-slate-400 mb-6">
              Start with our free plan and upgrade as your automation needs grow. 
              No credit card required for the free tier.
            </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                icon="Rocket"
                onClick={() => window.open('https://app.n8ncopilot.com/signup', '_blank')}
              >
                Start Free Now
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                icon="Phone"
                onClick={() => window.open('https://calendly.com/n8ncopilot/sales', '_blank')}
              >
                Talk to Sales
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default Pricing