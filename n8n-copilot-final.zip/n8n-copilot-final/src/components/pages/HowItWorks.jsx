import { useState } from 'react'
import { motion } from 'framer-motion'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import StepCard from '@/components/molecules/StepCard'
import ApperIcon from '@/components/ApperIcon'

const HowItWorks = () => {
  const [activeStep, setActiveStep] = useState(0)
  
  const steps = [
    {
      number: 1,
      title: 'Describe Your Automation',
      description: 'Tell us what you want to automate in plain English. Be as detailed or as general as you like.',
      icon: 'MessageSquare',
      details: [
        'Natural language processing understands your intent',
        'No technical jargon required',
        'Examples and suggestions provided',
        'Support for complex multi-step workflows'
      ],
      example: 'When someone fills out my contact form, send them a welcome email and add them to my CRM with a follow-up task.'
    },
    {
      number: 2,
      title: 'AI Asks Follow-ups',
      description: 'Our intelligent clarification engine asks targeted questions to understand your specific requirements.',
      icon: 'Brain',
      details: [
        'Dynamic question generation based on your input',
        'Clarifies ambiguous requirements',
        'Suggests best practices and alternatives',
        'Ensures complete workflow specification'
      ],
      example: 'Which CRM do you use? What should the follow-up task say? Do you want to segment contacts by form source?'
    },
    {
      number: 3,
      title: 'Generate Deployable Artifacts',
      description: 'Receive complete workflows with numbered steps, exportable JSON, visual diagrams, and code snippets.',
      icon: 'FileText',
      details: [
        'Production-ready n8n workflow JSON',
        'Visual Mermaid diagrams',
        'Step-by-step implementation guide',
        'Code snippets for custom nodes'
      ],
      example: 'Complete workflow with webhook trigger, email service integration, CRM API calls, and error handling.'
    },
    {
      number: 4,
      title: 'Deploy with One Click',
      description: 'Connect your n8n instance and deploy workflows directly, or export JSON for manual import.',
      icon: 'Zap',
      details: [
        'Direct n8n API integration',
        'Secure connection to your instance',
        'Automatic workflow validation',
        'Rollback capabilities for safety'
      ],
      example: 'Workflow automatically deployed to your n8n instance, tested, and ready to receive webhooks.'
    }
  ]
  
  const benefits = [
    {
      icon: 'Clock',
      title: 'Save Time',
      description: 'From hours to minutes - generate complex workflows instantly'
    },
    {
      icon: 'Shield',
      title: 'Reduce Errors',
      description: 'AI-generated workflows follow best practices and include error handling'
    },
    {
      icon: 'Users',
      title: 'Enable Teams',
      description: 'Non-technical team members can create sophisticated automations'
    },
    {
      icon: 'Lightbulb',
      title: 'Learn Faster',
      description: 'See how complex workflows are structured and learn n8n patterns'
    }
  ]
  
  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            How n8n Copilot Works
          </h1>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            Transform your workflow ideas into production-ready n8n automations 
            in four simple steps. No technical expertise required.
          </p>
        </motion.div>
        
        {/* Steps Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => setActiveStep(index)}
              className="cursor-pointer"
            >
              <StepCard
                {...step}
                isActive={activeStep === index}
              />
            </motion.div>
          ))}
        </div>
        
        {/* Active Step Details */}
        <motion.div
          key={activeStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-20"
        >
          <Card glass className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
                    <ApperIcon name={steps[activeStep].icon} className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white">
                      {steps[activeStep].title}
                    </h3>
                    <p className="text-slate-400">
                      Step {steps[activeStep].number} of 4
                    </p>
                  </div>
                </div>
                
                <p className="text-slate-300 mb-6 leading-relaxed">
                  {steps[activeStep].description}
                </p>
                
                <ul className="space-y-2">
                  {steps[activeStep].details.map((detail, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <ApperIcon name="Check" className="text-success flex-shrink-0 mt-0.5" size={16} />
                      <span className="text-slate-400">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-surface/50 rounded-lg p-6">
                <h4 className="text-lg font-semibold text-white mb-3">
                  Example
                </h4>
                <p className="text-slate-300 leading-relaxed font-mono text-sm">
                  {steps[activeStep].example}
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Why Choose n8n Copilot?
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              More than just workflow generation - we're revolutionizing how teams approach automation.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass hover className="text-center h-full">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <ApperIcon name={benefit.icon} className="text-primary" size={24} />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-slate-400 leading-relaxed">
                    {benefit.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Process Flow */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <Card glass className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-white mb-4">
                The Complete Process
              </h3>
              <p className="text-slate-400">
                From idea to deployment in minutes, not hours
              </p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between text-sm text-slate-400">
                <span>Start</span>
                <span>~2-5 minutes</span>
                <span>Complete</span>
              </div>
              
              <div className="relative">
                <div className="h-2 bg-surface rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary to-secondary"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 2, delay: 0.5 }}
                  />
                </div>
                
                <div className="absolute top-0 left-0 w-full h-2 flex justify-between">
                  {steps.map((_, index) => (
                    <div
                      key={index}
                      className="w-4 h-4 bg-gradient-to-r from-primary to-secondary rounded-full -mt-1"
                    />
                  ))}
                </div>
              </div>
              
              <div className="flex justify-between text-xs text-slate-500">
                {steps.map((step, index) => (
                  <span key={index} className="text-center max-w-[80px]">
                    {step.title}
                  </span>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <Card glass className="max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              Ready to try it yourself?
            </h3>
            <p className="text-slate-400 mb-6">
              Experience the power of AI-driven workflow generation. 
              Start building better automations today.
            </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                icon="Rocket"
                onClick={() => window.open('https://app.n8ncopilot.com/signup', '_blank')}
              >
                Get Started Free
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                icon="PlayCircle"
                onClick={() => window.open('https://demo.n8ncopilot.com', '_blank')}
              >
                Watch Demo
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default HowItWorks