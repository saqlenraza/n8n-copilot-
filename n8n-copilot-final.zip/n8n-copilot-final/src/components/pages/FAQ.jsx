import { motion } from 'framer-motion'
import Badge from '@/components/atoms/Badge'
import Card from '@/components/atoms/Card'
import Button from '@/components/atoms/Button'
import FAQItem from '@/components/molecules/FAQItem'
import ApperIcon from '@/components/ApperIcon'

const FAQ = () => {
  const faqCategories = [
    {
      title: 'Getting Started',
      faqs: [
        {
          question: 'What if my workflow description is vague?',
          answer: 'Our AI Clarification Engine is designed to handle vague descriptions by asking intelligent follow-up questions. It will guide you through the process of defining your automation requirements, suggesting common patterns and best practices along the way.'
        },
        {
          question: 'Do I need technical knowledge to use n8n Copilot?',
          answer: 'No technical knowledge is required to describe your workflows, but having some familiarity with n8n will help you customize and optimize the generated workflows. Our tool is designed to bridge the gap between non-technical users and technical implementation.'
        },
        {
          question: 'How accurate are the generated workflows?',
          answer: 'Our AI generates workflows based on best practices and common patterns. While the generated workflows are production-ready, we recommend reviewing and testing them in your specific environment before deployment. The accuracy improves as you provide more detailed descriptions.'
        }
      ]
    },
    {
      title: 'Technical Questions',
      faqs: [
        {
          question: 'Which n8n versions are supported?',
          answer: 'n8n Copilot supports all recent self-hosted versions of n8n (v0.180.0 and above) via the REST API. We continuously update our compatibility to support the latest n8n features and nodes. Cloud-hosted n8n instances are also supported with proper API access.'
        },
        {
          question: 'Can I use n8n Copilot with other automation platforms?',
          answer: 'Currently, n8n Copilot is optimized for n8n workflows. However, we\'re developing early beta support for Zapier and Make (formerly Integromat). The AI-generated logic can often be adapted to other platforms with some modifications.'
        },
        {
          question: 'What happens to my data and workflow descriptions?',
          answer: 'Your data privacy is our priority. Workflow descriptions are processed securely and are not stored permanently unless you choose to save them. For self-hosted deployments, all data remains within your infrastructure. We never use your data to train our models.'
        },
        {
          question: 'Can I modify the generated workflows?',
          answer: 'Absolutely! The generated JSON workflows are fully editable in n8n. You can modify nodes, add custom logic, adjust triggers, and customize the workflow to your exact needs. Think of our output as a sophisticated starting point rather than a final product.'
        }
      ]
    },
    {
      title: 'Features & Capabilities',
      faqs: [
        {
          question: 'What types of workflows can n8n Copilot create?',
          answer: 'n8n Copilot can generate a wide variety of workflows including data synchronization, email automation, webhook processing, API integrations, file processing, notification systems, and complex multi-step business processes. The AI understands common automation patterns and can handle both simple and complex scenarios.'
        },
        {
          question: 'Does it support custom nodes and community packages?',
          answer: 'Yes! n8n Copilot can generate workflows that use both built-in n8n nodes and community-contributed nodes. Just mention the specific tools or services you want to integrate, and our AI will use the appropriate nodes if they\'re available in the n8n ecosystem.'
        },
        {
          question: 'Can I export workflows to other formats?',
          answer: 'Currently, we export workflows as n8n-compatible JSON files and visual Mermaid diagrams. We\'re working on additional export formats including documentation, code snippets, and compatibility with other automation platforms.'
        },
        {
          question: 'How does the visual diagram generation work?',
          answer: 'Our AI analyzes the workflow logic and generates interactive Mermaid diagrams that visualize the flow of data and control. These diagrams are perfect for documentation, team collaboration, and understanding complex workflows before deployment.'
        }
      ]
    },
    {
      title: 'Pricing & Plans',
      faqs: [
        {
          question: 'Is there a free tier available?',
          answer: 'Yes! Our free tier includes unlimited text-based workflow planning, AI clarification, basic visualization, and up to 5 workflow generations per month. This is perfect for trying out the service and handling occasional automation needs.'
        },
        {
          question: 'What\'s included in the Pro plan?',
          answer: 'The Pro plan includes unlimited workflow generation, JSON and diagram exports, custom branding, direct n8n API integration, priority support, and access to advanced workflow templates. It\'s designed for individuals and small teams with regular automation needs.'
        },
        {
          question: 'When should I consider Enterprise?',
          answer: 'Enterprise is ideal for larger organizations that need SSO integration, comprehensive audit logs, on-premise deployment, custom integrations, dedicated support, and SLA guarantees. It\'s built for teams that require enterprise-grade security and compliance features.'
        },
        {
          question: 'Can I change plans anytime?',
          answer: 'Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately for upgrades, and downgrades are processed at the end of your current billing cycle. We\'ll help you migrate your data and settings seamlessly.'
        }
      ]
    },
    {
      title: 'Security & Compliance',
      faqs: [
        {
          question: 'Is n8n Copilot SOC 2 compliant?',
          answer: 'Yes, n8n Copilot is SOC 2 Type II compliant. We undergo regular security audits and maintain strict controls for data security, availability, and confidentiality. Our compliance documentation is available for Enterprise customers.'
        },
        {
          question: 'How does self-hosting work?',
          answer: 'Self-hosting gives you complete control over your n8n Copilot instance. You can deploy it on your own infrastructure, behind your firewall, with your own security controls. We provide Docker images, deployment guides, and support for major cloud platforms and on-premise environments.'
        },
        {
          question: 'What about GDPR and HIPAA compliance?',
          answer: 'n8n Copilot is designed to be GDPR and HIPAA compliant. For GDPR, we provide data portability, deletion rights, and transparent data processing. For HIPAA, our Enterprise plan includes business associate agreements and additional security controls required for healthcare data.'
        },
        {
          question: 'How do you handle API keys and sensitive data?',
          answer: 'API keys and sensitive configuration data are encrypted at rest and in transit. For self-hosted deployments, this data never leaves your infrastructure. We use industry-standard encryption and follow security best practices for credential management.'
        }
      ]
    }
  ]
  
  return (
    <div className="min-h-screen py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="primary" size="md" className="mb-4">
            <ApperIcon name="HelpCircle" size={14} />
            Frequently Asked Questions
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Get Your Questions Answered
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            Everything you need to know about n8n Copilot, from getting started to advanced features and enterprise deployment.
          </p>
        </motion.div>
        
        {/* Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-12"
        >
          <Card glass className="max-w-2xl mx-auto">
            <div className="relative">
              <ApperIcon name="Search" className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" size={20} />
              <input
                type="text"
                placeholder="Search frequently asked questions..."
                className="w-full bg-transparent border-none pl-12 pr-4 py-3 text-slate-200 placeholder-slate-400 focus:outline-none text-lg"
              />
            </div>
          </Card>
        </motion.div>
        
        {/* FAQ Categories */}
        <div className="space-y-12">
          {faqCategories.map((category, categoryIndex) => (
            <motion.div
              key={categoryIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 + categoryIndex * 0.1 }}
            >
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-white mb-2">
                  {category.title}
                </h2>
                <div className="h-1 w-20 bg-gradient-to-r from-primary to-secondary rounded-full" />
              </div>
              
              <div className="space-y-4">
                {category.faqs.map((faq, faqIndex) => (
                  <motion.div
                    key={faqIndex}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.4 + faqIndex * 0.1 }}
                  >
                    <FAQItem {...faq} />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Still Have Questions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mt-20"
        >
          <Card glass className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-6">
              <ApperIcon name="MessageCircle" className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">
              Still Have Questions?
            </h3>
            <p className="text-slate-400 mb-6 max-w-2xl mx-auto">
              Can't find what you're looking for? Our support team is here to help. 
              Reach out through any of these channels and we'll get back to you quickly.
            </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                icon="Mail" 
                variant="outline"
                onClick={() => window.open('mailto:support@n8ncopilot.com', '_self')}
              >
                Email Support
              </Button>
              <Button 
                icon="MessageSquare" 
                variant="outline"
                onClick={() => window.open('https://chat.n8ncopilot.com', '_blank')}
              >
                Live Chat
              </Button>
              <Button 
                icon="Calendar" 
                variant="outline"
                onClick={() => window.open('https://calendly.com/n8ncopilot/support', '_blank')}
              >
                Schedule Call
              </Button>
            </div>
          </Card>
        </motion.div>
        
        {/* Quick Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mt-12"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card glass hover className="text-center">
              <ApperIcon name="Book" className="text-primary mx-auto mb-3" size={24} />
              <h4 className="text-lg font-semibold text-white mb-2">
                Documentation
              </h4>
              <p className="text-slate-400 text-sm mb-4">
                Comprehensive guides and API reference
              </p>
<Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.open('https://docs.n8ncopilot.com', '_blank')}
              >
                View Docs
              </Button>
            </Card>
            
            <Card glass hover className="text-center">
              <ApperIcon name="Users" className="text-primary mx-auto mb-3" size={24} />
              <h4 className="text-lg font-semibold text-white mb-2">
                Community
              </h4>
              <p className="text-slate-400 text-sm mb-4">
                Connect with other users and experts
              </p>
<Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.open('https://discord.gg/n8ncopilot', '_blank')}
              >
                Join Discord
              </Button>
            </Card>
            
            <Card glass hover className="text-center">
              <ApperIcon name="PlayCircle" className="text-primary mx-auto mb-3" size={24} />
              <h4 className="text-lg font-semibold text-white mb-2">
                Tutorials
              </h4>
              <p className="text-slate-400 text-sm mb-4">
                Step-by-step video tutorials
              </p>
<Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.open('https://youtube.com/n8ncopilot', '_blank')}
              >
                Watch Now
              </Button>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default FAQ