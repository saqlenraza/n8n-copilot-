import { motion } from "framer-motion";
import Card from "@/components/atoms/Card";
import Badge from "@/components/atoms/Badge";
import Button from "@/components/atoms/Button";
import FeatureCard from "@/components/molecules/FeatureCard";
import ApperIcon from "@/components/ApperIcon";
import React from "react";

const Features = () => {
  const coreFeatures = [
    {
      title: 'AI Clarification Engine',
      description: 'Our intelligent system asks targeted questions to understand your exact automation requirements, ensuring precision in every generated workflow.',
      icon: 'Brain',
      gradient: true,
      details: [
        'Dynamic question generation based on context',
        'Identifies ambiguous requirements automatically',
        'Suggests best practices and alternatives',
        'Learns from your preferences over time'
      ]
    },
    {
      title: 'Exportable Workflow JSON',
      description: 'Get production-ready n8n workflow JSON files that you can import directly into your n8n instance without any modifications.',
      icon: 'FileJson',
      gradient: true,
      details: [
        'Complete n8n-compatible JSON structure',
        'Includes all node configurations and connections',
        'Error handling and validation built-in',
        'Optimized for performance and reliability'
      ]
    },
    {
      title: 'Visual Diagrams',
      description: 'See your workflow logic in beautiful, interactive Mermaid diagrams that help you understand and validate the automation flow.',
      icon: 'GitBranch',
      gradient: true,
      details: [
        'Interactive Mermaid diagram generation',
        'Zoom and pan capabilities for complex workflows',
        'Multiple diagram styles and layouts',
        'Export diagrams as PNG or SVG'
      ]
    },
    {
      title: 'Direct n8n Integration',
      description: 'Connect your n8n instance directly and deploy workflows with a single click, complete with automatic validation and testing.',
      icon: 'Link',
      gradient: true,
      details: [
        'Secure API connection to your n8n instance',
        'Automatic workflow validation before deployment',
        'Built-in testing and error detection',
        'Rollback capabilities for safety'
      ]
    },
    {
      title: 'Self-Hostable & Compliant',
      description: 'Deploy n8n Copilot on your own infrastructure with full SOC 2 compliance and enterprise-grade security features.',
      icon: 'Shield',
      gradient: true,
      details: [
        'Complete self-hosting capabilities',
        'SOC 2 Type II compliance',
        'GDPR and HIPAA ready',
        'Enterprise security controls'
      ]
    },
    {
      title: 'Team Management',
      description: 'Collaborate with your team using advanced user management, role-based access control, and comprehensive audit logging.',
      icon: 'Users',
      gradient: true,
      details: [
        'Role-based access control',
        'Team collaboration features',
        'Comprehensive audit logs',
        'Activity tracking and reporting'
      ]
    }
  ]
  
  const technicalFeatures = [
    {
      title: 'Multi-Platform Support',
      description: 'Beyond n8n, we\'re adding support for Zapier, Make, and other automation platforms.',
      icon: 'Grid3x3'
    },
    {
      title: 'API-First Design',
      description: 'Integrate n8n Copilot into your existing tools and workflows using our comprehensive API.',
      icon: 'Code'
    },
    {
      title: 'Version Control',
      description: 'Track changes to your workflows with built-in version control and rollback capabilities.',
      icon: 'GitCommit'
    },
    {
      title: 'Template Library',
      description: 'Access a growing library of pre-built templates for common automation patterns.',
      icon: 'BookOpen'
    },
    {
      title: 'Custom Node Support',
      description: 'Generate workflows that use custom nodes and community packages.',
      icon: 'Package'
    },
    {
      title: 'Advanced Scheduling',
      description: 'Set up complex schedules and triggers for time-based automations.',
      icon: 'Calendar'
    }
  ]
  
  const integrations = [
    { name: 'n8n', icon: 'Bot', status: 'Available' },
    { name: 'Zapier', icon: 'Zap', status: 'Coming Soon' },
    { name: 'Make', icon: 'Settings', status: 'Coming Soon' },
    { name: 'GitHub', icon: 'Github', status: 'Available' },
    { name: 'Slack', icon: 'MessageCircle', status: 'Available' },
    { name: 'Discord', icon: 'Hash', status: 'Available' },
    { name: 'Webhook', icon: 'Webhook', status: 'Available' },
    { name: 'REST API', icon: 'Globe', status: 'Available' }
  ]
  
  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="primary" size="md" className="mb-4">
            <ApperIcon name="Star" size={14} />
            Full Feature Suite
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Powerful Features for Every Team
          </h1>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            From AI-powered generation to enterprise-grade security, 
            n8n Copilot has everything you need to build, deploy, and manage automations at scale.
          </p>
        </motion.div>
        
        {/* Core Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Core Features
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              The essential tools that make workflow automation effortless and powerful.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {coreFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group"
              >
                <Card glass hover className="h-full">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                      <ApperIcon name={feature.icon} className="text-white" size={24} />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-slate-400 mb-4 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                  
                  <ul className="space-y-2">
                    {feature.details.map((detail, detailIndex) => (
                      <li key={detailIndex} className="flex items-start gap-2 text-sm">
                        <ApperIcon name="Check" className="text-success flex-shrink-0 mt-0.5" size={14} />
                        <span className="text-slate-400">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Technical Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Technical Excellence
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              Advanced features for developers and technical teams who need more control and flexibility.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {technicalFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card glass hover className="h-full">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-surface border border-slate-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <ApperIcon name={feature.icon} className="text-primary" size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-slate-400 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Integrations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Integrations & Compatibility
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              Works seamlessly with your existing tools and automation platforms.
            </p>
          </div>
          
          <Card glass className="max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {integrations.map((integration, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-surface border border-slate-600 rounded-2xl flex items-center justify-center mx-auto mb-3 hover:border-primary transition-colors">
                    <ApperIcon name={integration.icon} className="text-slate-300" size={24} />
                  </div>
                  <h4 className="text-sm font-medium text-white mb-1">
                    {integration.name}
                  </h4>
                  <Badge 
                    variant={integration.status === 'Available' ? 'success' : 'outline'}
                    size="sm"
                  >
                    {integration.status}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
        
        {/* Feature Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Why Choose n8n Copilot?
            </h2>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto">
              See how we compare to traditional workflow building methods.
            </p>
          </div>
          
          <Card glass className="max-w-4xl mx-auto">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-4 px-6 text-white font-semibold">Feature</th>
                    <th className="text-center py-4 px-6 text-white font-semibold">Manual Building</th>
                    <th className="text-center py-4 px-6 text-white font-semibold">n8n Copilot</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 px-6 text-slate-300">Time to Build</td>
                    <td className="py-4 px-6 text-center text-slate-400">Hours to Days</td>
                    <td className="py-4 px-6 text-center text-success">Minutes</td>
                  </tr>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 px-6 text-slate-300">Technical Expertise</td>
                    <td className="py-4 px-6 text-center text-slate-400">Required</td>
                    <td className="py-4 px-6 text-center text-success">Optional</td>
                  </tr>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 px-6 text-slate-300">Error Handling</td>
                    <td className="py-4 px-6 text-center text-slate-400">Manual</td>
                    <td className="py-4 px-6 text-center text-success">Automatic</td>
                  </tr>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 px-6 text-slate-300">Best Practices</td>
                    <td className="py-4 px-6 text-center text-slate-400">Research Required</td>
                    <td className="py-4 px-6 text-center text-success">Built-in</td>
                  </tr>
                  <tr>
                    <td className="py-4 px-6 text-slate-300">Documentation</td>
                    <td className="py-4 px-6 text-center text-slate-400">Manual</td>
                    <td className="py-4 px-6 text-center text-success">Auto-generated</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </motion.div>
        
        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <Card glass className="max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              Experience All Features
            </h3>
            <p className="text-slate-400 mb-6">
              Try n8n Copilot with full access to all features. 
              No credit card required, no time limits on core functionality.
            </p>
<div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                icon="Rocket"
                onClick={() => window.open('https://app.n8ncopilot.com/signup', '_blank')}
              >
                Start Free Trial
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                icon="Calendar"
                onClick={() => window.open('https://calendly.com/n8ncopilot/demo', '_blank')}
              >
                Schedule Demo
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default Features