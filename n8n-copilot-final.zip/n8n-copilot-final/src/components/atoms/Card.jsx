import { motion } from 'framer-motion'

const Card = ({ 
  children, 
  className = '', 
  hover = false,
  glass = false,
  glow = false,
  ...props 
}) => {
  const baseClasses = 'rounded-xl p-6 transition-all duration-300 relative overflow-hidden'
  const glassClasses = glass ? 'glass-card-enhanced' : 'bg-surface/80 backdrop-blur-sm border border-slate-600/50'
  const hoverClasses = hover ? 'card-hover-effect cursor-pointer' : ''
  const glowClasses = glow ? 'glow-effect' : ''
  
  const classes = `${baseClasses} ${glassClasses} ${hoverClasses} ${glowClasses} ${className}`
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      whileHover={hover ? { 
        y: -4,
        transition: { duration: 0.2 }
      } : {}}
      className={classes}
      {...props}
    >
      {/* Subtle gradient overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
      
      {/* Animated border effect on hover */}
      {hover && (
        <motion.div
          className="absolute inset-0 rounded-xl border-2 border-primary/0 transition-colors duration-300"
          whileHover={{ borderColor: 'rgba(99, 102, 241, 0.3)' }}
        />
      )}
    </motion.div>
  )
}

export default Card