import { forwardRef } from 'react'
import ApperIcon from '@/components/ApperIcon'

const Textarea = forwardRef(({ 
  label, 
  error, 
  rows = 4,
  className = '',
  ...props 
}, ref) => {
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-slate-200 mb-2">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        rows={rows}
        className={`
          w-full bg-surface border border-slate-700 rounded-lg px-4 py-3 
          text-slate-200 placeholder-slate-400 
          focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent
          transition-all duration-200 resize-vertical
          ${error ? 'border-error focus:ring-error' : ''}
          ${className}
        `}
        {...props}
      />
      {error && (
        <p className="text-sm text-error mt-1 flex items-center gap-1">
          <ApperIcon name="AlertCircle" size={16} />
          {error}
        </p>
      )}
    </div>
  )
})

Textarea.displayName = 'Textarea'

export default Textarea