import { motion } from 'framer-motion'

const Loading = ({ type = 'card' }) => {
  const shimmer = {
    animate: {
      backgroundPosition: ['200% 0', '-200% 0'],
    },
    transition: {
      duration: 1.5,
      repeat: Infinity,
      ease: 'linear'
    }
  }
  
  if (type === 'card') {
    return (
      <div className="space-y-6">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="glass-card rounded-xl p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="flex items-center space-x-4">
              <motion.div
                className="w-12 h-12 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded-xl"
                animate={shimmer.animate}
                transition={shimmer.transition}
                style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
              />
              <div className="flex-1 space-y-2">
                <motion.div
                  className="h-4 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded"
                  animate={shimmer.animate}
                  transition={shimmer.transition}
                  style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
                />
                <motion.div
                  className="h-3 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded w-3/4"
                  animate={shimmer.animate}
                  transition={shimmer.transition}
                  style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
                />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    )
  }
  
  if (type === 'grid') {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="glass-card rounded-xl p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="space-y-4">
              <motion.div
                className="w-16 h-16 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded-2xl"
                animate={shimmer.animate}
                transition={shimmer.transition}
                style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
              />
              <div className="space-y-2">
                <motion.div
                  className="h-5 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded"
                  animate={shimmer.animate}
                  transition={shimmer.transition}
                  style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
                />
                <motion.div
                  className="h-3 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded w-4/5"
                  animate={shimmer.animate}
                  transition={shimmer.transition}
                  style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
                />
                <motion.div
                  className="h-3 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 bg-[length:200%_100%] rounded w-3/5"
                  animate={shimmer.animate}
                  transition={shimmer.transition}
                  style={{ backgroundImage: 'linear-gradient(90deg, #334155 0%, #475569 50%, #334155 100%)' }}
                />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    )
  }
  
  return (
    <div className="flex items-center justify-center py-12">
      <div className="flex items-center gap-3">
        <motion.div
          className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-full"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <span className="text-slate-400">Loading...</span>
      </div>
    </div>
  )
}

export default Loading