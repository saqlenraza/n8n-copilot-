import workflowsData from '@/services/mockData/workflows.json'

class WorkflowService {
  constructor() {
    this.workflows = [...workflowsData]
  }

  async delay(ms = 300) {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  async getAll() {
    await this.delay()
    return [...this.workflows]
  }

  async getById(id) {
    await this.delay()
    const workflow = this.workflows.find(w => w.Id === parseInt(id))
    return workflow ? { ...workflow } : null
  }

  async create(workflowData) {
    await this.delay()
    const newWorkflow = {
      ...workflowData,
      Id: Math.max(...this.workflows.map(w => w.Id), 0) + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    this.workflows.push(newWorkflow)
    return { ...newWorkflow }
  }

  async update(id, updates) {
    await this.delay()
    const index = this.workflows.findIndex(w => w.Id === parseInt(id))
    if (index === -1) return null
    
    this.workflows[index] = {
      ...this.workflows[index],
      ...updates,
      updatedAt: new Date().toISOString()
    }
    return { ...this.workflows[index] }
  }

  async delete(id) {
    await this.delay()
    const index = this.workflows.findIndex(w => w.Id === parseInt(id))
    if (index === -1) return false
    
    this.workflows.splice(index, 1)
    return true
  }

  async generateWorkflow(description, clarifications = []) {
    await this.delay(2000) // Simulate AI processing time
    
    const generatedWorkflow = {
      Id: Math.max(...this.workflows.map(w => w.Id), 0) + 1,
      name: this.generateWorkflowName(description),
      description,
      clarifications,
      status: 'generated',
      json: this.generateN8nJson(description),
      diagram: this.generateMermaidDiagram(description),
      steps: this.generateSteps(description),
      nodes: this.generateNodes(description),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    this.workflows.push(generatedWorkflow)
    return { ...generatedWorkflow }
  }

  generateWorkflowName(description) {
    const words = description.split(' ').slice(0, 4)
    return words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') + ' Workflow'
  }

generateN8nJson(description) {
    const analysis = this.analyzeWorkflowRequirements(description)
    const nodes = []
    const connections = {}
    let nodeIdCounter = 1
    let yPosition = 300
    const xSpacing = 250
    
    // Generate trigger node based on analysis
    const triggerNode = this.createTriggerNode(analysis, nodeIdCounter++, 100, yPosition)
    nodes.push(triggerNode)
    
    let previousNodeId = triggerNode.id
    let currentX = 100 + xSpacing
    
    // Add data processing if needed
    if (analysis.needsProcessing) {
      const processNode = this.createProcessingNode(analysis, nodeIdCounter++, currentX, yPosition)
      nodes.push(processNode)
      this.addConnection(connections, previousNodeId, processNode.id)
      previousNodeId = processNode.id
      currentX += xSpacing
    }
    
    // Add conditional logic if detected
    if (analysis.hasConditions) {
      const conditionNode = this.createConditionNode(analysis, nodeIdCounter++, currentX, yPosition)
      nodes.push(conditionNode)
      this.addConnection(connections, previousNodeId, conditionNode.id)
      previousNodeId = conditionNode.id
      currentX += xSpacing
    }
    
    // Add service integrations
    analysis.services.forEach((service, index) => {
      const serviceNode = this.createServiceNode(service, analysis, nodeIdCounter++, currentX, yPosition + (index * 100))
      nodes.push(serviceNode)
      this.addConnection(connections, previousNodeId, serviceNode.id, analysis.hasConditions ? (index === 0 ? 0 : 1) : 0)
      if (index === 0 && !analysis.hasConditions) {
        previousNodeId = serviceNode.id
        currentX += xSpacing
      }
    })
    
    // Add database operations if needed
    if (analysis.needsDatabase) {
      const dbNode = this.createDatabaseNode(analysis, nodeIdCounter++, currentX, yPosition)
      nodes.push(dbNode)
      this.addConnection(connections, previousNodeId, dbNode.id)
      currentX += xSpacing
    }
    
    // Add response handling
    if (analysis.needsResponse) {
      const responseNode = this.createResponseNode(analysis, nodeIdCounter++, currentX, yPosition)
      nodes.push(responseNode)
      this.addConnection(connections, previousNodeId, responseNode.id)
    }
    
    return {
      nodes,
      connections,
      active: true,
      settings: {
        executionOrder: 'v1',
        saveManualExecutions: true,
        callerPolicy: 'workflowsFromSameOwner'
      },
      staticData: {},
      meta: {
        instanceId: '12345abcdef'
      }
    }
  }

  analyzeWorkflowRequirements(description) {
    const lower = description.toLowerCase()
    
    return {
      triggerType: this.detectTriggerType(lower),
      services: this.extractServices(lower),
      hasConditions: /\b(if|when|condition|check|filter|validate)\b/.test(lower),
      needsProcessing: /\b(process|transform|parse|format|clean|extract)\b/.test(lower),
      needsDatabase: /\b(save|store|database|record|persist|log)\b/.test(lower),
      needsResponse: /\b(respond|reply|return|send back|confirm)\b/.test(lower),
      dataOperations: this.extractDataOperations(lower),
      errorHandling: /\b(error|fail|retry|fallback|exception)\b/.test(lower)
    }
  }

  detectTriggerType(description) {
    if (/\b(webhook|api|http|post|get)\b/.test(description)) return 'webhook'
    if (/\b(form|submit|contact)\b/.test(description)) return 'form'
    if (/\b(email|mail|inbox)\b/.test(description)) return 'email'
    if (/\b(schedule|cron|daily|weekly|time)\b/.test(description)) return 'schedule'
    if (/\b(file|upload|document)\b/.test(description)) return 'file'
    return 'webhook' // Default fallback
  }

  extractServices(description) {
    const services = []
    const serviceMap = {
      'gmail': 'gmail', 'email': 'emailSend', 'mail': 'emailSend',
      'slack': 'slack', 'discord': 'discord', 'teams': 'microsoftTeams',
      'airtable': 'airtable', 'notion': 'notion', 'sheets': 'googleSheets',
      'trello': 'trello', 'asana': 'asana', 'jira': 'jira',
      'shopify': 'shopify', 'woocommerce': 'wooCommerce',
      'stripe': 'stripe', 'paypal': 'payPal',
      'twitter': 'twitter', 'facebook': 'facebookGraphApi',
      'linkedin': 'linkedIn', 'instagram': 'instagram'
    }
    
    Object.keys(serviceMap).forEach(key => {
      if (description.includes(key)) {
        services.push({ name: key, type: serviceMap[key] })
      }
    })
    
    return services
  }

  extractDataOperations(description) {
    const operations = []
    if (/\b(create|add|insert)\b/.test(description)) operations.push('create')
    if (/\b(update|modify|change)\b/.test(description)) operations.push('update')
    if (/\b(delete|remove)\b/.test(description)) operations.push('delete')
    if (/\b(get|fetch|retrieve|read)\b/.test(description)) operations.push('read')
    return operations
  }

  createTriggerNode(analysis, id, x, y) {
    const triggerConfigs = {
      webhook: {
        type: 'n8n-nodes-base.webhook',
        name: 'Webhook Trigger',
        parameters: {
          httpMethod: 'POST',
          path: 'workflow-trigger',
          responseMode: 'onReceived'
        }
      },
      form: {
        type: 'n8n-nodes-base.formTrigger',
        name: 'Form Trigger',
        parameters: {
          path: 'form-submission'
        }
      },
      email: {
        type: 'n8n-nodes-base.emailReadImap',
        name: 'Email Trigger',
        parameters: {
          pollTimes: { item: [{ mode: 'everyMinute' }] }
        }
      },
      schedule: {
        type: 'n8n-nodes-base.cron',
        name: 'Schedule Trigger',
        parameters: {
          triggerTimes: { item: [{ hour: 9, minute: 0 }] }
        }
      }
    }
    
    const config = triggerConfigs[analysis.triggerType] || triggerConfigs.webhook
    
    return {
      id: `node${id}`,
      ...config,
      position: [x, y],
      webhookId: analysis.triggerType === 'webhook' ? 'webhook-' + Date.now() : undefined
    }
  }

  createProcessingNode(analysis, id, x, y) {
    return {
      id: `node${id}`,
      type: 'n8n-nodes-base.function',
      name: 'Process Data',
      parameters: {
        functionCode: `// Enhanced data processing
const processedItems = items.map(item => {
  const data = item.json;
  
  // Data validation and transformation
  const processed = {
    ...data,
    processed: true,
    timestamp: new Date().toISOString(),
    id: data.id || Date.now(),
    // Add custom processing based on workflow needs
    ${analysis.dataOperations.includes('create') ? 'status: "created",' : ''}
    ${analysis.dataOperations.includes('update') ? 'lastModified: new Date().toISOString(),' : ''}
  };
  
  return processed;
});

return processedItems;`
      },
      position: [x, y]
    }
  }

  createConditionNode(analysis, id, x, y) {
    return {
      id: `node${id}`,
      type: 'n8n-nodes-base.if',
      name: 'Condition Check',
      parameters: {
        conditions: {
          options: {
            caseSensitive: true,
            leftValue: '',
            typeValidation: 'strict'
          },
          conditions: [
            {
              leftValue: '={{ $json.data }}',
              rightValue: '',
              operation: 'notEmpty'
            }
          ],
          combinator: 'and'
        }
      },
      position: [x, y]
    }
  }

  createServiceNode(service, analysis, id, x, y) {
    const serviceConfigs = {
      emailSend: {
        type: 'n8n-nodes-base.emailSend',
        name: 'Send Email',
        parameters: {
          fromEmail: 'automation@example.com',
          toEmail: '={{ $json.email }}',
          subject: 'Workflow Notification',
          message: 'Your workflow has been processed successfully.',
          options: {}
        }
      },
      slack: {
        type: 'n8n-nodes-base.slack',
        name: 'Slack Message',
        parameters: {
          channel: '#general',
          text: 'Workflow notification: {{ $json.message }}',
          username: 'Workflow Bot'
        }
      },
      airtable: {
        type: 'n8n-nodes-base.airtable',
        name: 'Airtable',
        parameters: {
          operation: 'append',
          application: 'app12345',
          table: 'Table 1'
        }
      }
    }
    
    const config = serviceConfigs[service.type] || serviceConfigs.emailSend
    
    return {
      id: `node${id}`,
      ...config,
      position: [x, y]
    }
  }

  createDatabaseNode(analysis, id, x, y) {
    return {
      id: `node${id}`,
      type: 'n8n-nodes-base.postgres',
      name: 'Save to Database',
      parameters: {
        operation: 'insert',
        schema: 'public',
        table: 'workflow_data',
        columns: 'id,data,created_at',
        additionalFields: {}
      },
      position: [x, y]
    }
  }

  createResponseNode(analysis, id, x, y) {
    return {
      id: `node${id}`,
      type: 'n8n-nodes-base.respondToWebhook',
      name: 'Send Response',
      parameters: {
        options: {},
        respondWith: 'json',
        responseBody: '{{ {"success": true, "message": "Workflow completed successfully", "timestamp": "' + new Date().toISOString() + '"} }}'
      },
      position: [x, y]
    }
  }

  addConnection(connections, fromNodeId, toNodeId, outputIndex = 0) {
    if (!connections[fromNodeId]) {
      connections[fromNodeId] = { main: [] }
    }
    if (!connections[fromNodeId].main[outputIndex]) {
      connections[fromNodeId].main[outputIndex] = []
    }
    connections[fromNodeId].main[outputIndex].push({
      node: toNodeId,
      type: 'main',
      index: 0
    })
  }

generateMermaidDiagram(description) {
    const analysis = this.analyzeWorkflowRequirements(description)
    let diagram = 'graph TD\n'
    let nodeCounter = 1
    
    // Define node styles
    diagram += '    classDef triggerClass fill:#6366f1,stroke:#4f46e5,stroke-width:2px,color:#fff\n'
    diagram += '    classDef processClass fill:#8b5cf6,stroke:#7c3aed,stroke-width:2px,color:#fff\n'
    diagram += '    classDef conditionClass fill:#14b8a6,stroke:#059669,stroke-width:2px,color:#fff\n'
    diagram += '    classDef serviceClass fill:#f59e0b,stroke:#d97706,stroke-width:2px,color:#fff\n'
    diagram += '    classDef endClass fill:#ef4444,stroke:#dc2626,stroke-width:2px,color:#fff\n\n'
    
    // Start with trigger
    const triggerLabel = this.getTriggerLabel(analysis.triggerType)
    diagram += `    A[${triggerLabel}]:::triggerClass\n`
    let currentNode = 'A'
    let nextNodeLetter = 'B'
    
    // Add processing if needed
    if (analysis.needsProcessing) {
      diagram += `    ${currentNode} --> ${nextNodeLetter}[Process & Transform Data]:::processClass\n`
      currentNode = nextNodeLetter
      nextNodeLetter = String.fromCharCode(nextNodeLetter.charCodeAt(0) + 1)
    }
    
    // Add conditions
    if (analysis.hasConditions) {
      diagram += `    ${currentNode} --> ${nextNodeLetter}{Validate Conditions}:::conditionClass\n`
      const conditionNode = nextNodeLetter
      nextNodeLetter = String.fromCharCode(nextNodeLetter.charCodeAt(0) + 1)
      
      // Handle service branches
      if (analysis.services.length > 0) {
        analysis.services.forEach((service, index) => {
          const serviceNode = String.fromCharCode(nextNodeLetter.charCodeAt(0) + index)
          const serviceLabel = this.getServiceLabel(service)
          diagram += `    ${conditionNode} -->|Condition Met| ${serviceNode}[${serviceLabel}]:::serviceClass\n`
        })
        
        // Add rejection path
        const rejectNode = String.fromCharCode(nextNodeLetter.charCodeAt(0) + analysis.services.length)
        diagram += `    ${conditionNode} -->|Condition Failed| ${rejectNode}[End - No Action]:::endClass\n`
        nextNodeLetter = String.fromCharCode(rejectNode.charCodeAt(0) + 1)
        currentNode = String.fromCharCode(nextNodeLetter.charCodeAt(0) - analysis.services.length - 1)
      }
    } else if (analysis.services.length > 0) {
      // Direct service connections without conditions
      analysis.services.forEach((service, index) => {
        const serviceNode = nextNodeLetter
        const serviceLabel = this.getServiceLabel(service)
        diagram += `    ${currentNode} --> ${serviceNode}[${serviceLabel}]:::serviceClass\n`
        
        if (index === 0) {
          currentNode = serviceNode
        }
        nextNodeLetter = String.fromCharCode(nextNodeLetter.charCodeAt(0) + 1)
      })
    }
    
    // Add database operations
    if (analysis.needsDatabase) {
      diagram += `    ${currentNode} --> ${nextNodeLetter}[Save to Database]:::serviceClass\n`
      currentNode = nextNodeLetter
      nextNodeLetter = String.fromCharCode(nextNodeLetter.charCodeAt(0) + 1)
    }
    
    // Add response handling
    if (analysis.needsResponse) {
      diagram += `    ${currentNode} --> ${nextNodeLetter}[Send Response]:::processClass\n`
      currentNode = nextNodeLetter
      nextNodeLetter = String.fromCharCode(nextNodeLetter.charCodeAt(0) + 1)
    }
    
    // End the workflow
    if (!analysis.needsResponse && !analysis.hasConditions) {
      diagram += `    ${currentNode} --> ${nextNodeLetter}[Workflow Complete]:::endClass\n`
    }
    
    return diagram
  }

  getTriggerLabel(triggerType) {
    const labels = {
      webhook: 'Webhook Trigger',
      form: 'Form Submission',
      email: 'Email Received',
      schedule: 'Scheduled Trigger',
      file: 'File Upload'
    }
    return labels[triggerType] || 'Webhook Trigger'
  }

  getServiceLabel(service) {
    const labels = {
      gmail: 'Send Gmail',
      emailSend: 'Send Email',
      slack: 'Post to Slack',
      airtable: 'Update Airtable',
      notion: 'Create Notion Page',
      sheets: 'Update Google Sheets',
      stripe: 'Process Payment',
      shopify: 'Update Shopify'
    }
    return labels[service.type] || service.name || 'External Service'
  }

generateSteps(description) {
    const analysis = this.analyzeWorkflowRequirements(description)
    const steps = []
    
    // Add trigger step
    const triggerLabels = {
      webhook: 'Receive webhook payload and validate structure',
      form: 'Capture form submission data and validate fields',
      email: 'Monitor inbox and parse incoming email content',
      schedule: 'Execute scheduled workflow at defined intervals',
      file: 'Detect file upload and extract metadata'
    }
    steps.push(triggerLabels[analysis.triggerType] || triggerLabels.webhook)
    
    // Add data processing steps
    if (analysis.needsProcessing) {
      steps.push('Transform and validate incoming data structure')
      if (analysis.dataOperations.includes('create')) {
        steps.push('Generate unique identifiers and timestamps')
      }
      if (analysis.dataOperations.includes('update')) {
        steps.push('Merge new data with existing records')
      }
    }
    
    // Add conditional logic steps
    if (analysis.hasConditions) {
      steps.push('Evaluate business rules and routing conditions')
      steps.push('Route data based on conditional logic outcomes')
    }
    
    // Add service integration steps
    analysis.services.forEach(service => {
      const serviceActions = {
        emailSend: 'Compose and send personalized email notification',
        slack: 'Format message and post to designated Slack channel',
        airtable: 'Create or update records in Airtable base',
        notion: 'Generate structured page in Notion workspace',
        sheets: 'Append data to Google Sheets with formatting',
        stripe: 'Process payment and handle transaction events',
        shopify: 'Update product inventory and customer records'
      }
      steps.push(serviceActions[service.type] || `Integrate with ${service.name} service`)
    })
    
    // Add database operations
    if (analysis.needsDatabase) {
      if (analysis.dataOperations.includes('create')) {
        steps.push('Insert new records into database with validation')
      }
      if (analysis.dataOperations.includes('update')) {
        steps.push('Update existing database records with new data')
      }
      if (analysis.dataOperations.includes('delete')) {
        steps.push('Remove specified records from database')
      }
      if (!analysis.dataOperations.length) {
        steps.push('Save processed data to database with indexing')
      }
    }
    
    // Add error handling if detected
    if (analysis.errorHandling) {
      steps.push('Implement error handling and retry mechanisms')
      steps.push('Log failures and send error notifications')
    }
    
    // Add response handling
    if (analysis.needsResponse) {
      steps.push('Generate structured response with execution status')
      steps.push('Return confirmation data to requesting system')
    } else {
      steps.push('Complete workflow execution and update audit logs')
    }
    
    return steps
  }

generateNodes(description) {
    const analysis = this.analyzeWorkflowRequirements(description)
    const nodes = []
    
    // Add trigger node
    const triggerNodes = {
      webhook: { type: 'n8n-nodes-base.webhook', name: 'Webhook Trigger', category: 'trigger', icon: 'webhook' },
      form: { type: 'n8n-nodes-base.formTrigger', name: 'Form Trigger', category: 'trigger', icon: 'form' },
      email: { type: 'n8n-nodes-base.emailReadImap', name: 'Email Trigger', category: 'trigger', icon: 'email' },
      schedule: { type: 'n8n-nodes-base.cron', name: 'Schedule Trigger', category: 'trigger', icon: 'clock' },
      file: { type: 'n8n-nodes-base.localFileTrigger', name: 'File Trigger', category: 'trigger', icon: 'file' }
    }
    nodes.push(triggerNodes[analysis.triggerType] || triggerNodes.webhook)
    
    // Add processing node if needed
    if (analysis.needsProcessing) {
      nodes.push({
        type: 'n8n-nodes-base.function',
        name: 'Process Data',
        category: 'transform',
        icon: 'function',
        description: 'Transform and validate data structure'
      })
    }
    
    // Add conditional logic
    if (analysis.hasConditions) {
      nodes.push({
        type: 'n8n-nodes-base.if',
        name: 'Condition Check',
        category: 'logic',
        icon: 'git-branch',
        description: 'Route based on business rules'
      })
    }
    
    // Add service nodes
    analysis.services.forEach(service => {
      const serviceNodes = {
        emailSend: { type: 'n8n-nodes-base.emailSend', name: 'Send Email', category: 'communication', icon: 'mail' },
        slack: { type: 'n8n-nodes-base.slack', name: 'Slack', category: 'communication', icon: 'slack' },
        airtable: { type: 'n8n-nodes-base.airtable', name: 'Airtable', category: 'productivity', icon: 'airtable' },
        notion: { type: 'n8n-nodes-base.notion', name: 'Notion', category: 'productivity', icon: 'notion' },
        sheets: { type: 'n8n-nodes-base.googleSheets', name: 'Google Sheets', category: 'productivity', icon: 'google-sheets' },
        stripe: { type: 'n8n-nodes-base.stripe', name: 'Stripe', category: 'finance', icon: 'stripe' },
        shopify: { type: 'n8n-nodes-base.shopify', name: 'Shopify', category: 'ecommerce', icon: 'shopify' }
      }
      
      const nodeConfig = serviceNodes[service.type] || {
        type: `n8n-nodes-base.${service.type}`,
        name: service.name,
        category: 'integration',
        icon: 'external-link'
      }
      
      nodes.push({
        ...nodeConfig,
        description: `Integrate with ${service.name} service`
      })
    })
    
    // Add database node if needed
    if (analysis.needsDatabase) {
      nodes.push({
        type: 'n8n-nodes-base.postgres',
        name: 'Database',
        category: 'storage',
        icon: 'database',
        description: 'Store and retrieve workflow data'
      })
    }
    
    // Add HTTP request node for API calls
    if (description.toLowerCase().includes('api') || description.toLowerCase().includes('http')) {
      nodes.push({
        type: 'n8n-nodes-base.httpRequest',
        name: 'HTTP Request',
        category: 'network',
        icon: 'globe',
        description: 'Make API calls to external services'
      })
    }
    
    // Add response node if needed
    if (analysis.needsResponse) {
      nodes.push({
        type: 'n8n-nodes-base.respondToWebhook',
        name: 'Send Response',
        category: 'communication',
        icon: 'send',
        description: 'Return structured response data'
      })
    }
    
    return nodes
  }
}

export default new WorkflowService()