import mockUsers from '@/services/mockData/users.json'

// Simulate database with in-memory storage
let users = [...mockUsers]
let nextId = Math.max(...users.map(u => u.Id)) + 1

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))

const userService = {
  async getAll() {
    await delay(300)
    return [...users]
  },

  async getById(id) {
    await delay(300)
    const numericId = parseInt(id)
    if (isNaN(numericId)) {
      throw new Error('Invalid user ID')
    }
    const user = users.find(u => u.Id === numericId)
    if (!user) {
      throw new Error('User not found')
    }
    return { ...user }
  },

  async getByEmail(email) {
    await delay(300)
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase())
    return user ? { ...user } : null
  },

  async create(userData) {
    await delay(300)
    
    // Check if email already exists
    const existingUser = users.find(u => u.email.toLowerCase() === userData.email.toLowerCase())
    if (existingUser) {
      throw new Error('Email already registered')
    }

    const newUser = {
      Id: nextId++,
      name: userData.name,
      email: userData.email.toLowerCase(),
      password: userData.password,
      role: userData.role || 'user',
      createdAt: new Date().toISOString(),
      lastLogin: null,
      isActive: true,
      preferences: {
        theme: 'dark',
        notifications: true,
        language: 'en'
      }
    }

    users.push(newUser)
    return { ...newUser }
  },

  async update(id, userData) {
    await delay(300)
    const numericId = parseInt(id)
    if (isNaN(numericId)) {
      throw new Error('Invalid user ID')
    }

    const userIndex = users.findIndex(u => u.Id === numericId)
    if (userIndex === -1) {
      throw new Error('User not found')
    }

    // Check if email is being changed and already exists
    if (userData.email && userData.email !== users[userIndex].email) {
      const existingUser = users.find(u => u.email.toLowerCase() === userData.email.toLowerCase())
      if (existingUser && existingUser.Id !== numericId) {
        throw new Error('Email already in use')
      }
    }

    const updatedUser = {
      ...users[userIndex],
      ...userData,
      Id: numericId, // Prevent ID changes
      email: userData.email ? userData.email.toLowerCase() : users[userIndex].email
    }

    users[userIndex] = updatedUser
    return { ...updatedUser }
  },

  async delete(id) {
    await delay(300)
    const numericId = parseInt(id)
    if (isNaN(numericId)) {
      throw new Error('Invalid user ID')
    }

    const userIndex = users.findIndex(u => u.Id === numericId)
    if (userIndex === -1) {
      throw new Error('User not found')
    }

    const deletedUser = users[userIndex]
    users.splice(userIndex, 1)
    return { ...deletedUser }
  },

  async updateLastLogin(id) {
    await delay(100)
    const numericId = parseInt(id)
    const userIndex = users.findIndex(u => u.Id === numericId)
    if (userIndex !== -1) {
      users[userIndex].lastLogin = new Date().toISOString()
      return { ...users[userIndex] }
    }
    return null
  }
}

export default userService