import userService from './userService'

// Simulate session storage
let currentSession = null

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))

const authService = {
  async login(email, password) {
    await delay(300)
    
    if (!email || !password) {
      throw new Error('Email and password are required')
    }

    const user = await userService.getByEmail(email)
    if (!user) {
      throw new Error('Invalid email or password')
    }

    if (user.password !== password) {
      throw new Error('Invalid email or password')
    }

    if (!user.isActive) {
      throw new Error('Account is disabled')
    }

    // Update last login
    await userService.updateLastLogin(user.Id)
    
    // Create session
    currentSession = {
      userId: user.Id,
      loginTime: new Date().toISOString(),
      token: `mock-token-${user.Id}-${Date.now()}`
    }

    // Store in localStorage for persistence
    localStorage.setItem('authSession', JSON.stringify(currentSession))

    // Return user without password
    const { password: _, ...userWithoutPassword } = user
    return {
      user: userWithoutPassword,
      token: currentSession.token
    }
  },

  async signup(userData) {
    await delay(300)

    if (!userData.name || !userData.email || !userData.password) {
      throw new Error('Name, email, and password are required')
    }

    if (userData.password.length < 6) {
      throw new Error('Password must be at least 6 characters')
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(userData.email)) {
throw new Error('Invalid email format')
  }

  try {
    const newUser = await userService.create(userData)
    
    // Auto-login after signup using the newly created user data
      // Update last login
      await userService.updateLastLogin(newUser.Id)
      
      // Create session
      currentSession = {
        userId: newUser.Id,
        loginTime: new Date().toISOString(),
        token: `mock-token-${newUser.Id}-${Date.now()}`
      }

      // Store in localStorage for persistence
      localStorage.setItem('authSession', JSON.stringify(currentSession))

      // Return user without password
      const { password: _, ...userWithoutPassword } = newUser
      return {
        user: userWithoutPassword,
        token: currentSession.token
      }
    } catch (error) {
      throw error
    }
  },

  async logout() {
    await delay(100)
    currentSession = null
    localStorage.removeItem('authSession')
    return { success: true }
  },

  async getCurrentUser() {
    await delay(200)
    
    // Check current session
    if (!currentSession) {
      // Try to restore from localStorage
      const storedSession = localStorage.getItem('authSession')
      if (storedSession) {
        currentSession = JSON.parse(storedSession)
      } else {
        return null
      }
    }

    try {
      const user = await userService.getById(currentSession.userId)
      if (!user || !user.isActive) {
        currentSession = null
        localStorage.removeItem('authSession')
        return null
      }

      // Return user without password
      const { password: _, ...userWithoutPassword } = user
      return userWithoutPassword
    } catch (error) {
      currentSession = null
      localStorage.removeItem('authSession')
      return null
    }
  },

  async changePassword(currentPassword, newPassword) {
    await delay(300)
    
    if (!currentSession) {
      throw new Error('Not authenticated')
    }

    if (!currentPassword || !newPassword) {
      throw new Error('Current password and new password are required')
    }

    if (newPassword.length < 6) {
      throw new Error('New password must be at least 6 characters')
    }

    const user = await userService.getById(currentSession.userId)
    if (user.password !== currentPassword) {
      throw new Error('Current password is incorrect')
    }

    await userService.update(user.Id, { password: newPassword })
    return { success: true }
  },

  async updateProfile(profileData) {
    await delay(300)
    
    if (!currentSession) {
      throw new Error('Not authenticated')
    }

    const updatedUser = await userService.update(currentSession.userId, profileData)
    
    // Return user without password
    const { password: _, ...userWithoutPassword } = updatedUser
    return userWithoutPassword
  }
}

export default authService