# n8n Copilot - Improved UI/UX Version with Dedicated Workflow Builder

An AI-powered workflow generation tool for n8n with enhanced user interface, experience, and a dedicated workflow builder page.

## 🚀 What's New in This Version

### **NEW: Dedicated Workflow Builder Page**
- **Multi-Step Wizard**: Guided workflow creation with progress indicators
- **AI Clarifications**: Intelligent follow-up questions for better accuracy
- **Example Templates**: Pre-built workflow examples for common use cases
- **Enhanced Preview**: Visual workflow preview with statistics
- **One-Click Export**: Direct JSON download with deployment instructions

### UI/UX Improvements
- **Enhanced Visual Design**: Improved color contrast, better typography, and modern glass morphism effects
- **Better Animations**: Smooth micro-interactions, hover effects, and loading states
- **Improved Accessibility**: Better focus states, touch targets, and keyboard navigation
- **Mobile Optimization**: Enhanced mobile navigation and responsive design
- **Performance**: Optimized animations and reduced bundle size

### Key Features
- **AI-Powered Workflow Generation**: Describe your automation in plain English
- **Intelligent Clarification**: AI asks follow-up questions for better accuracy
- **Exportable JSON**: Production-ready n8n workflow files
- **Visual Diagrams**: Beautiful Mermaid diagrams of your workflows
- **One-Click Deploy**: Direct deployment to your n8n instance

## 🛠 Installation & Setup

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Quick Start
1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

### Production Deployment
The `dist/` folder contains the built application ready for deployment to any static hosting service.

## 🎯 New Workflow Builder

### Access the Builder
- Navigate to `/builder` in your browser
- Or click "Builder" in the main navigation
- No authentication required for basic access

### How It Works
1. **Describe Your Workflow** - Tell us what you want to automate in plain English
2. **Answer Clarifications** - Help us understand your specific requirements
3. **Review & Generate** - See your workflow and download the JSON
4. **Deploy to n8n** - Import the JSON file into your n8n instance

### Example Use Cases
- **Email Automation**: Contact form to CRM integration
- **Social Media Monitoring**: Brand mention notifications
- **Data Synchronization**: Stripe to Google Sheets sync
- **Content Publishing**: Blog post to social media automation

## 📁 Project Structure

```
src/
├── components/
│   ├── atoms/          # Basic UI components (Button, Card, Input)
│   ├── molecules/      # Composite components (WorkflowBuilder, FeatureCard)
│   ├── organisms/      # Complex components (Header, Footer, Layout)
│   └── pages/          # Page components (including WorkflowBuilder)
├── contexts/           # React contexts (Auth, etc.)
├── services/           # API services and mock data
└── index.css          # Global styles and animations
```

## 🎨 Design System

### Colors
- Primary: `#6366f1` (Indigo)
- Secondary: `#8b5cf6` (Purple)
- Accent: `#14b8a6` (Teal)
- Background: Gradient from `#0f172a` to `#1e293b`

### Components
- **Enhanced Buttons**: Multiple variants with hover effects and loading states
- **Glass Cards**: Modern glass morphism design with subtle animations
- **Responsive Navigation**: Mobile-optimized with smooth transitions
- **Multi-Step Wizard**: Progress indicators and step-by-step guidance

### Animations
- Fade-in animations for page loads
- Hover effects with scale and shadow
- Loading skeletons for better perceived performance
- Smooth transitions between states

## 🔧 Technical Improvements

### Performance
- Optimized bundle size (4.1MB built)
- Lazy loading for better initial load times
- Efficient animations using Framer Motion

### Accessibility
- Improved color contrast ratios
- Better focus management
- Touch-friendly mobile interface
- Semantic HTML structure

### Developer Experience
- Clean component architecture
- Consistent styling with Tailwind CSS
- Type-safe development patterns

## 📱 Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## 🤝 Contributing
This is an improved version of the original n8n-copilot project with enhanced UI/UX and a dedicated workflow builder. The improvements focus on:
- Better user experience
- Modern design patterns
- Improved accessibility
- Mobile optimization
- Dedicated workflow creation interface

## 📄 License
Same as original project license.

---

**Note**: This version includes significant UI/UX improvements and a new dedicated workflow builder page while maintaining all original functionality. The project is optimized for production deployment and includes a complete build in the `dist/` folder.

